import { useState, useEffect } from "react";

// ========== CONSTANTS ==========
const SITES = [
  { id: "qatour", name: "عنبر قطور", barns: ["عنبر 1"] },
  { id: "sayari", name: "مزرعة الصيري", barns: ["عنبر 1", "عنبر 2", "عنبر 3"] },
  { id: "elwad", name: "مزرعة الوادي", barns: ["عنبر 1", "عنبر 2", "عنبر 3", "عنبر 4"] },
  { id: "taha", name: "عنبر طه", barns: ["عنبر 1", "عنبر 2", "عنبر 3", "عنبر 4"] },
];

const SUPA_URL = "https://devxozrfoxvypllmhijj.supabase.co";
const SUPA_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRldnhvenJmb3h2eXBsbG1oaWpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEyMTA1NzgsImV4cCI6MjA5Njc4NjU3OH0.JnYQyOnYf501SjkNtMBp1GGyLhtQQ8gAY6ElXnjrVRk";
const SUPA_HDR = { "apikey": SUPA_KEY, "Authorization": `Bearer ${SUPA_KEY}`, "Content-Type": "application/json" };

// ========== DATA HELPERS ==========
const num = (v) => parseFloat(v) || 0;
const genId = () => Math.random().toString(36).slice(2, 9);

const emptyShift = () => ({ mortality: "", feed: "" });
const emptySession = (barnName) => ({
  barnName, startDate: "", birdCount: "", active: true,
  dailyRecords: [], weeklyWeights: [],
});

const makeEmpty = () => {
  const sites = {};
  SITES.forEach(s => {
    sites[s.id] = { sessions: {}, archive: [], feedStore: { received: [], dispatched: [] }, medStore: { received: [] }, gasStore: { received: [] }, injections: [] };
    s.barns.forEach(b => { sites[s.id].sessions[b] = null; });
  });
  return { sites };
};

const mergeData = (d) => {
  const empty = makeEmpty();
  if (!d || !d.sites) return empty;
  SITES.forEach(site => {
    if (!d.sites[site.id]) { d.sites[site.id] = empty.sites[site.id]; return; }
    site.barns.forEach(b => { if (!(b in d.sites[site.id].sessions)) d.sites[site.id].sessions[b] = null; });
    if (!d.sites[site.id].feedStore) d.sites[site.id].feedStore = { received: [], dispatched: [] };
    if (!d.sites[site.id].archive) d.sites[site.id].archive = [];
    if (!d.sites[site.id].medStore || Array.isArray(d.sites[site.id].medStore)) d.sites[site.id].medStore = { received: [] };
    if (!d.sites[site.id].medStore.received) d.sites[site.id].medStore.received = [];
    if (!d.sites[site.id].gasStore) d.sites[site.id].gasStore = { received: [] };
    if (!d.sites[site.id].gasStore.received) d.sites[site.id].gasStore.received = [];
    if (!d.sites[site.id].injections) d.sites[site.id].injections = [];
  });
  return d;
};

const calcDayStats = (r) => ({
  mortality: num(r.night.mortality) + num(r.day.mortality),
  feed: num(r.night.feed) + num(r.day.feed),
});

const calcAge = (startDate) => {
  if (!startDate) return 0;
  return Math.floor((new Date() - new Date(startDate)) / 86400000);
};

const calcFCR = (totalFeed, avgWeightG, birds) => {
  if (!avgWeightG || !birds || !totalFeed) return "-";
  const meat = (num(avgWeightG) / 1000) * num(birds);
  return meat ? (totalFeed / meat).toFixed(2) : "-";
};

// ========== SUPABASE ==========
const supaCall = async (path, query = "", method = "GET", body = null, prefer = "") => {
  try {
    const h = { ...SUPA_HDR };
    if (prefer) h["Prefer"] = prefer;
    const url = `${SUPA_URL}/rest/v1/${path}${query ? "?" + query : ""}`;
    const res = await fetch(url, { method, headers: h, body: body ? JSON.stringify(body) : null });
    if (!res.ok) return null;
    const txt = await res.text();
    return txt ? JSON.parse(txt) : null;
  } catch { return null; }
};

const saveToSupa = async (data) => {
  try {
    await fetch(`${SUPA_URL}/rest/v1/farm_data`, {
      method: "POST",
      headers: { ...SUPA_HDR, "Prefer": "resolution=merge-duplicates" },
      body: JSON.stringify({ id: "main", data, updated_at: new Date().toISOString() })
    });
  } catch {}
};

const loadFromSupa = async () => {
  try {
    const rows = await supaCall("farm_data", "id=eq.main&select=*");
    return rows?.[0]?.data || null;
  } catch { return null; }
};

const saveData = async (data) => {
  try { localStorage.setItem("poultry_data", JSON.stringify(data)); } catch {}
  await saveToSupa(data);
};

const loadSaved = async () => {
  try {
    const remote = await loadFromSupa();
    if (remote) { try { localStorage.setItem("poultry_data", JSON.stringify(remote)); } catch {} return mergeData(remote); }
  } catch {}
  try { const s = localStorage.getItem("poultry_data"); if (s) return mergeData(JSON.parse(s)); } catch {}
  return null;
};

const downloadBackup = (data) => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `backup_${new Date().toISOString().split("T")[0]}.json`; a.click();
  URL.revokeObjectURL(url);
};

const restoreBackup = (file, onSuccess) => {
  const r = new FileReader();
  r.onload = async (e) => { try { const d = JSON.parse(e.target.result); await saveData(d); onSuccess(d); } catch { alert("ملف غلط!"); } };
  r.readAsText(file);
};

// ========== SUPABASE BACKUP ==========
const fetchBackups = async () => { try { return await supaCall("backups", "select=id,label,created_at&order=created_at.desc&limit=10") || []; } catch { return []; } };
const saveBackup = async (data, label) => { await supaCall("backups", "", "POST", { data, label: label || `نسخة ${new Date().toLocaleString("ar-EG")}` }); };
const restoreBackupById = async (id) => { try { const rows = await supaCall("backups", `id=eq.${id}&select=data`); return rows?.[0]?.data || null; } catch { return null; } };
const deleteBackupById = async (id) => { await supaCall("backups", `id=eq.${id}`, "DELETE"); };

// ========== SUPABASE USERS ==========
const fetchUsers = async () => {
  try {
    const res = await fetch(`${SUPA_URL}/rest/v1/users?select=*`, { headers: SUPA_HDR });
    return await res.json() || [];
  } catch { return []; }
};
const createUser = async (u) => { try { await fetch(`${SUPA_URL}/rest/v1/users`, { method: "POST", headers: { ...SUPA_HDR, "Prefer": "return=representation" }, body: JSON.stringify(u) }); } catch {} };
const updateUser = async (id, u) => { try { await fetch(`${SUPA_URL}/rest/v1/users?id=eq.${id}`, { method: "PATCH", headers: SUPA_HDR, body: JSON.stringify(u) }); } catch {} };
const deleteUser = async (id) => { try { await fetch(`${SUPA_URL}/rest/v1/users?id=eq.${id}`, { method: "DELETE", headers: SUPA_HDR }); } catch {} };

// ========== COLORS ==========
const C = {
  bg: "#f0f2f5", card: "#ffffff", cardAlt: "#e8ecf0",
  accent: "#1a73e8", accentD: "#1557b0",
  green: "#1e8c4e", red: "#c0392b", blue: "#2980b9", purple: "#7b2d8b",
  text: "#1a1a2e", muted: "#5a6375", border: "#ced6e0", input: "#f8f9fb",
};

// ========== CSS ==========
const css = `
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Cairo',sans-serif;background:${C.bg};color:${C.text};direction:rtl;min-height:100vh}
::-webkit-scrollbar{width:5px}::-webkit-scrollbar-thumb{background:${C.border};border-radius:3px}
input,select,textarea{font-family:'Cairo',sans-serif;direction:rtl}

.topbar{background:${C.card};border-bottom:2px solid ${C.accent};padding:0 14px;display:flex;align-items:center;justify-content:space-between;height:56px;position:sticky;top:0;z-index:100;box-shadow:0 2px 6px rgba(0,0,0,.08)}
.logo{font-size:18px;font-weight:800;color:${C.accent};display:flex;align-items:center;gap:8px;letter-spacing:1.5px}
.logo-sub{font-size:10px;color:${C.muted};font-weight:600}
.menu-btn{background:none;border:none;color:${C.text};font-size:22px;cursor:pointer;padding:4px 8px}

.main{display:flex;min-height:calc(100vh - 56px)}
.sidebar{width:240px;background:${C.card};border-left:1px solid ${C.border};padding:12px 0;flex-shrink:0;box-shadow:2px 0 6px rgba(0,0,0,.04)}
.sec-lbl{padding:6px 14px;font-size:10px;color:${C.muted};font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-top:8px}
.site-btn{width:100%;text-align:right;padding:10px 14px;background:none;border:none;color:${C.text};font-family:'Cairo',sans-serif;font-size:13px;font-weight:700;cursor:pointer;border-right:3px solid transparent;transition:all .2s;display:flex;align-items:center;gap:7px}
.site-btn:hover,.site-btn.active{background:${C.cardAlt};color:${C.accent};border-right-color:${C.accent}}
.barn-btn{width:100%;text-align:right;padding:8px 14px 8px 28px;background:none;border:none;color:${C.muted};font-family:'Cairo',sans-serif;font-size:12px;font-weight:600;cursor:pointer;border-right:3px solid transparent;transition:all .2s;display:flex;align-items:center;gap:6px}
.barn-btn:hover{color:${C.text};background:rgba(26,115,232,.05)}
.barn-btn.active{color:${C.accent};border-right-color:${C.accent};background:rgba(26,115,232,.08)}
.dot{width:7px;height:7px;border-radius:50%;background:${C.border};flex-shrink:0}
.dot.on{background:${C.green}}

.content{flex:1;padding:18px;overflow-y:auto}
.pg-title{font-size:18px;font-weight:800;color:${C.text};margin-bottom:3px}
.pg-sub{font-size:11px;color:${C.muted};margin-bottom:16px;font-weight:600}

.card{background:${C.card};border:1px solid ${C.border};border-radius:12px;padding:16px;margin-bottom:14px;box-shadow:0 1px 4px rgba(0,0,0,.05)}
.card-t{font-size:13px;font-weight:800;color:${C.text};margin-bottom:12px;display:flex;align-items:center;gap:5px}

.btn{padding:8px 16px;border-radius:8px;border:none;font-family:'Cairo',sans-serif;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:4px}
.btn-p{background:${C.accent};color:#fff}.btn-p:hover{background:${C.accentD}}
.btn-s{background:${C.green};color:#fff}.btn-s:hover{filter:brightness(1.1)}
.btn-d{background:${C.red};color:#fff}.btn-d:hover{filter:brightness(1.1)}
.btn-n{background:${C.cardAlt};color:${C.text};border:1px solid ${C.border}}.btn-n:hover{border-color:${C.accent};color:${C.accent}}
.btn-w{background:#fff3cd;color:#856404;border:1px solid #ffc107}
.btn-sm{padding:5px 11px;font-size:11px}
.btn-xs{padding:3px 8px;font-size:11px}

.fg{display:flex;flex-direction:column;gap:4px}
.lbl{font-size:11px;color:${C.muted};font-weight:700}
.inp{background:${C.input};border:1.5px solid ${C.border};border-radius:8px;padding:9px 11px;color:${C.text};font-family:'Cairo',sans-serif;font-size:13px;outline:none;transition:border .2s;width:100%}
.inp:focus{border-color:${C.accent};background:#fff}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}
.g4{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}

.shift-wrap{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.shift-box{background:${C.cardAlt};border-radius:10px;padding:13px;border:1px solid ${C.border}}
.shift-t{font-size:12px;font-weight:800;margin-bottom:10px}
.night{color:#5c35d6}.day{color:#b45309}

.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-bottom:14px}
.stat{background:${C.card};border-radius:10px;padding:12px;border:1px solid ${C.border};text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.04)}
.sv{font-size:20px;font-weight:800}
.sl{font-size:11px;color:${C.muted};margin-top:3px;font-weight:600}
.cg{color:${C.green}}.cr{color:${C.red}}.cy{color:${C.accent}}.cb{color:${C.blue}}.cp{color:${C.purple}}

.tbl{width:100%;border-collapse:collapse;font-size:12px}
.tbl th{background:${C.cardAlt};padding:9px 8px;text-align:center;color:${C.text};font-weight:800;border-bottom:2px solid ${C.border}}
.tbl td{padding:8px 8px;text-align:center;border-bottom:1px solid ${C.border};color:${C.text}}
.tbl tr:hover td{background:rgba(26,115,232,.03)}

.tabs{display:flex;gap:3px;margin-bottom:16px;background:${C.cardAlt};padding:3px;border-radius:10px;width:fit-content;flex-wrap:wrap}
.tab{padding:7px 14px;border-radius:7px;border:none;font-family:'Cairo',sans-serif;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;background:none;color:${C.muted}}
.tab.active{background:${C.accent};color:#fff;box-shadow:0 2px 5px rgba(26,115,232,.3)}

.badge{display:inline-block;padding:2px 8px;border-radius:16px;font-size:11px;font-weight:700}
.bg{background:rgba(30,140,78,.12);color:${C.green}}
.br{background:rgba(192,57,43,.12);color:${C.red}}
.by{background:rgba(26,115,232,.12);color:${C.accent}}
.bb{background:rgba(41,128,185,.12);color:${C.blue}}

.alert{padding:10px 14px;border-radius:8px;font-size:12px;margin-bottom:12px;font-weight:700}
.alert-ok{background:rgba(30,140,78,.1);border:1px solid rgba(30,140,78,.3);color:${C.green}}
.alert-err{background:rgba(192,57,43,.1);border:1px solid rgba(192,57,43,.3);color:${C.red}}

.home-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px}
.site-card{background:${C.card};border:1.5px solid ${C.border};border-radius:14px;padding:18px;cursor:pointer;transition:all .25s;border-top:3px solid ${C.accent};box-shadow:0 2px 6px rgba(0,0,0,.05)}
.site-card:hover{transform:translateY(-2px);box-shadow:0 6px 18px rgba(26,115,232,.12)}
.barn-tags{display:flex;flex-wrap:wrap;gap:5px;margin-top:10px}
.btag{font-size:11px;padding:3px 9px;border-radius:6px;background:${C.cardAlt};color:${C.muted};border:1px solid ${C.border};font-weight:600}
.btag.on{background:rgba(30,140,78,.1);color:${C.green};border-color:rgba(30,140,78,.3)}

.empty{text-align:center;padding:40px 20px;color:${C.muted}}
.empty .ico{font-size:40px;margin-bottom:10px}

.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:500;display:flex;align-items:center;justify-content:center;padding:14px}
.modal{background:${C.card};border:1.5px solid ${C.border};border-radius:14px;padding:22px;width:100%;max-width:420px;max-height:90vh;overflow-y:auto;box-shadow:0 10px 36px rgba(0,0,0,.15)}
.modal-t{font-size:14px;font-weight:800;color:${C.accent};margin-bottom:14px}

@media(max-width:700px){
  .sidebar{position:fixed;top:56px;right:-250px;width:240px;height:calc(100vh - 56px);z-index:300;transition:right .3s;overflow-y:auto}
  .sidebar.open{right:0}
  .content{padding:12px}
  .shift-wrap{grid-template-columns:1fr}
  .stats{grid-template-columns:repeat(2,1fr)}
  .tabs{width:100%}.tab{flex:1;text-align:center;font-size:11px;padding:6px 4px}
  .g2,.g3,.g4{grid-template-columns:1fr 1fr}
  .tbl{font-size:11px}.tbl th,.tbl td{padding:6px 4px}
  .home-grid{grid-template-columns:1fr}
  .sv{font-size:18px}
}
@media(min-width:701px){.menu-btn{display:none}}
`;

// ========== CONFIRM ==========
function Confirm({ msg, onOk, onCancel }) {
  return (
    <div className="modal-bg">
      <div className="modal" style={{ textAlign: "center", borderColor: C.red, maxWidth: 360 }}>
        <div style={{ fontSize: 30, marginBottom: 8 }}>⚠️</div>
        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 18, lineHeight: 1.7 }}>{msg}</div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn-n" style={{ flex: 1 }} onClick={onCancel}>إلغاء</button>
          <button className="btn btn-d" style={{ flex: 1 }} onClick={onOk}>تأكيد</button>
        </div>
      </div>
    </div>
  );
}

// ========== LOGIN ==========
function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [pass, setPass] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const go = async () => {
    if (!username || !pass) return;
    setLoading(true); setErr("");
    try {
      const res = await fetch(`${SUPA_URL}/rest/v1/users?username=eq.${encodeURIComponent(username)}&select=*`, { headers: SUPA_HDR });
      const rows = await res.json();
      if (!rows || rows.length === 0 || rows[0].password !== pass) {
        setErr("اسم المستخدم أو كلمة المرور غلط!"); setLoading(false); return;
      }
      onLogin(rows[0]);
    } catch { setErr("مشكلة في الاتصال"); }
    setLoading(false);
  };

  return (
    <div style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <style>{css}</style>
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 16, padding: 32, width: "100%", maxWidth: 320, textAlign: "center", boxShadow: "0 4px 20px rgba(0,0,0,.1)" }}>
        <img src="/logo.png" alt="مزارع أبوشريف" style={{ width: 175, height: 175, objectFit: "contain", marginBottom: 10 }} onError={e => { e.target.style.display='none'; }} />
        <div style={{ fontSize: 22, fontWeight: 800, color: C.accent, marginBottom: 2, letterSpacing: 2 }}>مزارع أبوشريف</div>
        <div style={{ fontSize: 10, color: C.muted, marginBottom: 22 }}>MAZARIE ABO SHERIF</div>
        {err && <div className="alert alert-err">{err}</div>}
        <div className="fg" style={{ textAlign: "right", marginBottom: 10 }}>
          <label className="lbl">👤 اسم المستخدم</label>
          <input className="inp" value={username} onChange={e => setUsername(e.target.value)} onKeyDown={e => e.key === "Enter" && go()} autoFocus />
        </div>
        <div className="fg" style={{ textAlign: "right", marginBottom: 18 }}>
          <label className="lbl">🔒 كلمة المرور</label>
          <input className="inp" type="password" value={pass} onChange={e => setPass(e.target.value)} onKeyDown={e => e.key === "Enter" && go()} />
        </div>
        <button className="btn btn-p" style={{ width: "100%", fontSize: 13, padding: "10px" }} onClick={go} disabled={loading}>{loading ? "جاري التحقق..." : "دخول"}</button>
      </div>
    </div>
  );
}

// ========== DAILY TAB ==========
// ========== DAILY TAB ==========
function DailyTab({ session, onUpdate, feedStore, medStore, onSaveRecord, onDeleteRecord, isAdmin }) {
  const canEdit = !!onUpdate;
  const today = new Date().toISOString().split("T")[0];
  const [form, setForm] = useState({ id: genId(), date: today, night: emptyShift(), day: emptyShift(), medicines: [] });
  const [medForm, setMedForm] = useState({ name: "" });
  const [saved, setSaved] = useState(false);
  const [editRec, setEditRec] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [err, setErr] = useState("");

  const setShift = (s, f, v) => setForm(p => ({ ...p, [s]: { ...p[s], [f]: v } }));

  const addMed = () => {
    if (!medForm.name.trim()) return;
    setForm(p => ({ ...p, medicines: [...p.medicines, { id: genId(), name: medForm.name.trim() }] }));
    setMedForm({ name: "" });
  };

  const save = () => {
    if (!onSaveRecord) return;
    const result = onSaveRecord({ ...form });
    if (!result.ok) { setErr(result.err || "حدث خطأ"); setTimeout(() => setErr(""), 4000); return; }
    setSaved(true); setTimeout(() => setSaved(false), 2500);
    setForm({ id: genId(), date: today, night: emptyShift(), day: emptyShift(), medicines: [] });
  };

  const saveEdit = () => {
    if (!onUpdate || !editRec) return;
    onUpdate({ ...session, dailyRecords: session.dailyRecords.map(r => r.id === editRec.id ? editRec : r) });
    setEditRec(null);
  };

  const deleteRec = (id) => {
    setConfirm({ msg: "هتمسح السجل اليومي ده؟ سيتم إرجاع العلف والدواء المسحوبين تلقائياً للمخزن.", fn: () => onDeleteRecord && onDeleteRecord(id) });
  };

  const tot = { mortality: num(form.night.mortality) + num(form.day.mortality), feed: num(form.night.feed) + num(form.day.feed) };
  const feedBalance = (feedStore?.received || []).reduce((s, r) => s + num(r.qty), 0) - (feedStore?.dispatched || []).reduce((s, r) => s + num(r.qty), 0);

  return (
    <div>
      {confirm && <Confirm msg={confirm.msg} onOk={() => { confirm.fn(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}
      {editRec && (
        <div className="modal-bg">
          <div className="modal">
            <div className="modal-t">✏️ تعديل السجل — {editRec.date}</div>
            <div style={{ fontSize: 11, color: C.muted, marginBottom: 10 }}>ملاحظة: تعديل كمية العلف/النافق هنا لا يغيّر المخزون تلقائياً</div>
            <div className="shift-wrap">
              {["night", "day"].map(s => (
                <div className="shift-box" key={s}>
                  <div className={`shift-t ${s}`}>{s === "night" ? "🌙 ليل" : "☀️ نهار"}</div>
                  <div className="g2">
                    <div className="fg"><label className="lbl">نافق</label><input className="inp" type="number" value={editRec[s].mortality} onChange={e => setEditRec(p => ({ ...p, [s]: { ...p[s], mortality: e.target.value } }))} /></div>
                    <div className="fg"><label className="lbl">علف (كجم)</label><input className="inp" type="number" value={editRec[s].feed} onChange={e => setEditRec(p => ({ ...p, [s]: { ...p[s], feed: e.target.value } }))} /></div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
              <button className="btn btn-n" style={{ flex: 1 }} onClick={() => setEditRec(null)}>إلغاء</button>
              <button className="btn btn-p" style={{ flex: 1 }} onClick={saveEdit}>💾 حفظ</button>
            </div>
          </div>
        </div>
      )}

      {saved && <div className="alert alert-ok">✅ تم الحفظ — تم خصم العلف والدواء من المخزن تلقائي</div>}
      {err && <div className="alert alert-err">⚠️ {err}</div>}
      <div className="card">
        <div className="card-t">📅 تسجيل يومي جديد</div>
        <div className="fg" style={{ marginBottom: 12, maxWidth: 180 }}>
          <label className="lbl">التاريخ</label>
          <input className="inp" type="date" value={form.date} onChange={e => setForm(p => ({ ...p, date: e.target.value }))} />
        </div>
        <div className="shift-wrap">
          {["night", "day"].map(s => (
            <div className="shift-box" key={s}>
              <div className={`shift-t ${s}`}>{s === "night" ? "🌙 شفت الليل" : "☀️ شفت النهار"}</div>
              <div className="g2">
                <div className="fg"><label className="lbl">نافق</label><input className="inp" type="number" placeholder="0" value={form[s].mortality} onChange={e => setShift(s, "mortality", e.target.value)} /></div>
                <div className="fg"><label className="lbl">علف (كجم)</label><input className="inp" type="number" placeholder="0" value={form[s].feed} onChange={e => setShift(s, "feed", e.target.value)} /></div>
              </div>
            </div>
          ))}
        </div>
        <div className="stats" style={{ marginTop: 10 }}>
          <div className="stat"><div className="sv cr">{tot.mortality}</div><div className="sl">إجمالي النافق</div></div>
          <div className="stat"><div className="sv cy">{tot.feed} كجم</div><div className="sl">إجمالي العلف</div></div>
          <div className="stat"><div className="sv" style={{color: feedBalance >= tot.feed ? C.green : C.red}}>{feedBalance.toFixed(0)} كجم</div><div className="sl">رصيد المخزن المتاح</div></div>
        </div>
      </div>

      <div className="card">
        <div className="card-t">💊 الأدوية المستخدمة اليوم</div>
        <div className="g2" style={{ marginBottom: 10 }}>
          <div className="fg">
            <label className="lbl">اسم الدواء المستخدم</label>
            <input className="inp" value={medForm.name} onChange={e => setMedForm({ name: e.target.value })} onKeyDown={e => e.key === "Enter" && addMed()} placeholder="اكتب اسم الدواء" />
          </div>
        </div>
        <button className="btn btn-n btn-sm" onClick={addMed}>+ إضافة دواء</button>
        {form.medicines.map((m, i) => (
          <div key={i} style={{ display: "flex", gap: 8, padding: "5px 10px", background: C.input, borderRadius: 6, marginTop: 6, fontSize: 11, alignItems: "center", flexWrap: "wrap" }}>
            <span style={{ fontWeight: 700 }}>💊 {m.name}</span>
            <button style={{ marginRight: "auto", background: "none", border: "none", color: C.red, cursor: "pointer", fontSize: 13 }} onClick={() => setForm(p => ({ ...p, medicines: p.medicines.filter((_, j) => j !== i) }))}>✕</button>
          </div>
        ))}
      </div>

      {canEdit && <button className="btn btn-p" style={{ fontSize: 13, padding: "10px 24px", marginBottom: 18 }} onClick={save}>💾 حفظ اليوم</button>}

      {session.dailyRecords.length > 0 && (
        <div className="card">
          <div className="card-t">📋 السجلات السابقة</div>
          <div style={{ overflowX: "auto" }}>
            <table className="tbl">
              <thead>
                <tr><th>التاريخ</th><th>العمر</th><th>نافق ل</th><th>نافق ن</th><th>إج نافق</th><th>علف ل</th><th>علف ن</th><th>إج علف</th><th>أدوية</th>{canEdit && <th>إجراء</th>}</tr>
              </thead>
              <tbody>
                {[...session.dailyRecords].reverse().map(r => {
                  const s = calcDayStats(r);
                  const age = session.startDate ? Math.floor((new Date(r.date) - new Date(session.startDate)) / 86400000) : "-";
                  return (
                    <tr key={r.id}>
                      <td>{r.date}</td>
                      <td><span className="badge by">{age} يوم</span></td>
                      <td style={{ color: C.red }}>{r.night.mortality || 0}</td>
                      <td style={{ color: C.red }}>{r.day.mortality || 0}</td>
                      <td><span className="badge br">{s.mortality}</span></td>
                      <td>{r.night.feed || 0}</td>
                      <td>{r.day.feed || 0}</td>
                      <td><span className="badge by">{s.feed} كجم</span></td>
                      <td>{(r.medicines || []).length > 0 ? <span className="badge" style={{background:"rgba(123,45,139,.12)", color:C.purple}}>{r.medicines.length} 💊</span> : "-"}</td>
                      {canEdit && <td><div style={{ display: "flex", gap: 3 }}><button className="btn btn-n btn-xs" onClick={() => setEditRec({ ...r })}>✏️</button>{isAdmin && <button className="btn btn-d btn-xs" onClick={() => deleteRec(r.id)}>🗑️</button>}</div></td>}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ========== WEIGHT TAB ==========
// ========== WEIGHT TAB ==========
function WeightTab({ session, onUpdate, isAdmin }) {
  const canEdit = !!onUpdate;
  const [form, setForm] = useState({ week: "", sampleCount: "", totalWeight: "" });
  const [editW, setEditW] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [saved, setSaved] = useState(false);

  const avg = form.sampleCount && form.totalWeight ? ((num(form.totalWeight) * 1000) / num(form.sampleCount)).toFixed(0) : "";
  const totalMort = (session.dailyRecords || []).reduce((s, r) => s + calcDayStats(r).mortality, 0);
  const remaining = num(session.birdCount) - totalMort;

  const feedUpToWeek = (wk) => {
    const start = new Date(session.startDate);
    return (session.dailyRecords || []).filter(r => (new Date(r.date) - start) / 86400000 < wk * 7).reduce((s, r) => s + calcDayStats(r).feed, 0);
  };

  const save = () => {
    if (!form.week || !form.sampleCount || !form.totalWeight || !onUpdate) return;
    const rec = { id: genId(), ...form, avgWeight: avg };
    onUpdate({ ...session, weeklyWeights: [...session.weeklyWeights, rec] });
    setSaved(true); setTimeout(() => setSaved(false), 2000);
    setForm({ week: "", sampleCount: "", totalWeight: "" });
  };

  const saveEdit = () => {
    if (!onUpdate || !editW) return;
    const newAvg = editW.sampleCount && editW.totalWeight ? ((num(editW.totalWeight) * 1000) / num(editW.sampleCount)).toFixed(0) : editW.avgWeight;
    onUpdate({ ...session, weeklyWeights: session.weeklyWeights.map(w => w.id === editW.id ? { ...editW, avgWeight: newAvg } : w) });
    setEditW(null);
  };

  return (
    <div>
      {confirm && <Confirm msg={confirm.msg} onOk={() => { confirm.fn(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}
      {editW && (
        <div className="modal-bg">
          <div className="modal">
            <div className="modal-t">✏️ تعديل وزن أسبوع {editW.week}</div>
            <div className="g2" style={{ marginBottom: 12 }}>
              <div className="fg"><label className="lbl">عدد العينة</label><input className="inp" type="number" value={editW.sampleCount} onChange={e => setEditW(p => ({ ...p, sampleCount: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">إجمالي الوزن (كجم)</label><input className="inp" type="number" value={editW.totalWeight} onChange={e => setEditW(p => ({ ...p, totalWeight: e.target.value }))} /></div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn btn-n" style={{ flex: 1 }} onClick={() => setEditW(null)}>إلغاء</button>
              <button className="btn btn-p" style={{ flex: 1 }} onClick={saveEdit}>💾 حفظ</button>
            </div>
          </div>
        </div>
      )}
      {saved && <div className="alert alert-ok">✅ تم الحفظ</div>}
      <div className="card">
        <div className="card-t">⚖️ تسجيل وزن أسبوعي</div>
        <div className="g4">
          <div className="fg"><label className="lbl">الأسبوع</label><input className="inp" type="number" placeholder="1" value={form.week} onChange={e => setForm(p => ({ ...p, week: e.target.value }))} /></div>
          <div className="fg"><label className="lbl">عدد العينة</label><input className="inp" type="number" placeholder="50" value={form.sampleCount} onChange={e => setForm(p => ({ ...p, sampleCount: e.target.value }))} /></div>
          <div className="fg"><label className="lbl">إجمالي الوزن (كجم)</label><input className="inp" type="number" value={form.totalWeight} onChange={e => setForm(p => ({ ...p, totalWeight: e.target.value }))} /></div>
          <div className="fg"><label className="lbl">متوسط (جم) — تلقائي</label><input className="inp" value={avg ? `${avg} جم` : ""} readOnly style={{ background: C.cardAlt, color: C.accent, fontWeight: 700 }} /></div>
        </div>
        {canEdit && <button className="btn btn-p btn-sm" style={{ marginTop: 10 }} onClick={save}>💾 حفظ</button>}
      </div>
      {session.weeklyWeights.length > 0 && (
        <div className="card">
          <div className="card-t">📊 معامل التحويل الأسبوعي</div>
          <div style={{ overflowX: "auto" }}>
            <table className="tbl">
              <thead><tr><th>الأسبوع</th><th>متوسط الوزن</th><th>إجمالي العلف</th><th>FCR</th>{canEdit && <th>إجراء</th>}</tr></thead>
              <tbody>
                {session.weeklyWeights.map(w => {
                  const tf = feedUpToWeek(num(w.week));
                  const fcr = calcFCR(tf, num(w.avgWeight), remaining);
                  return (
                    <tr key={w.id}>
                      <td>أسبوع {w.week}</td>
                      <td style={{ color: C.accent, fontWeight: 700 }}>{w.avgWeight} جم</td>
                      <td>{tf.toFixed(0)} كجم</td>
                      <td><span className="badge" style={{ background: num(fcr) < 2 ? "rgba(30,140,78,.12)" : "rgba(192,57,43,.12)", color: num(fcr) < 2 ? C.green : C.red }}>{fcr}</span></td>
                      {canEdit && <td><div style={{ display: "flex", gap: 3 }}><button className="btn btn-n btn-xs" onClick={() => setEditW({ ...w })}>✏️</button>{isAdmin && <button className="btn btn-d btn-xs" onClick={() => setConfirm({ msg: "هتمسح الوزن ده؟", fn: () => onUpdate({ ...session, weeklyWeights: session.weeklyWeights.filter(x => x.id !== w.id) }) })}>🗑️</button>}</div></td>}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ========== MEDICINE TAB ==========
function MedicineTab({ session, onEditMed, onDeleteMed, barnName, siteName, currentUser }) {
  const [editEntry, setEditEntry] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [showReport, setShowReport] = useState(false);

  const allMeds = (session?.dailyRecords || [])
    .flatMap(r => (r.medicines || []).map(m => ({
      ...m,
      recordId: r.id,
      date: r.date,
      age: session.startDate ? Math.floor((new Date(r.date) - new Date(session.startDate)) / 86400000) : "-"
    })))
    .sort((a, b) => a.date > b.date ? 1 : -1);

  const summary = {};
  allMeds.forEach(m => {
    if (!summary[m.name]) summary[m.name] = { count: 0, dates: [] };
    summary[m.name].count++;
    summary[m.name].dates.push(m.date);
  });

  const saveEdit = () => {
    if (!onEditMed || !editEntry) return;
    onEditMed(editEntry.recordId, editEntry.id, editEntry.name);
    setEditEntry(null);
  };

  return (
    <div>
      {showReport && (
        <SimpleReport
          title="تقرير سجل الأدوية"
          badge={`العنبر: ${barnName || "-"} — ${siteName || "-"}`}
          currentUser={currentUser}
          onClose={() => setShowReport(false)}
          sections={
            <>
              <div className="a4sechead">ملخص الأدوية</div>
              <table className="a4tbl">
                <thead><tr><th>الدواء</th><th>عدد الأيام</th><th>آخر استخدام</th></tr></thead>
                <tbody>
                  {Object.entries(summary).map(([name, info], i) => (
                    <tr key={i}><td><strong>{name}</strong></td><td>{info.count}</td><td>{info.dates[info.dates.length - 1]}</td></tr>
                  ))}
                </tbody>
              </table>
              <div className="a4sechead">سجل الأدوية يوم بيوم</div>
              <table className="a4tbl">
                <thead><tr><th>التاريخ</th><th>العمر</th><th>الدواء</th></tr></thead>
                <tbody>
                  {allMeds.map((m, i) => (
                    <tr key={i}><td>{m.date}</td><td>{m.age}</td><td>{m.name}</td></tr>
                  ))}
                </tbody>
              </table>
            </>
          }
        />
      )}
      {confirm && <Confirm msg={confirm.msg} onOk={() => { confirm.fn(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}
      {allMeds.length > 0 && <button className="btn btn-n btn-sm" style={{ marginBottom: 14 }} onClick={() => setShowReport(true)}>🖨️ طباعة تقرير الدواء</button>}
      {editEntry && (
        <div className="modal-bg">
          <div className="modal">
            <div className="modal-t">✏️ تعديل دواء — {editEntry.date}</div>
            <div className="fg" style={{ marginBottom: 12 }}>
              <label className="lbl">اسم الدواء</label>
              <input className="inp" value={editEntry.name} onChange={e => setEditEntry(p => ({ ...p, name: e.target.value }))} />
            </div>
            <div style={{ display: "flex", gap: 8 }}><button className="btn btn-n" style={{ flex: 1 }} onClick={() => setEditEntry(null)}>إلغاء</button><button className="btn btn-p" style={{ flex: 1 }} onClick={saveEdit}>💾 حفظ</button></div>
          </div>
        </div>
      )}

      {allMeds.length === 0 ? (
        <div className="empty"><div className="ico">💊</div><p>لا توجد أدوية مسجلة</p></div>
      ) : (
        <>
          <div className="card">
            <div className="card-t">📊 ملخص الأدوية</div>
            <div style={{ overflowX: "auto" }}>
              <table className="tbl">
                <thead><tr><th>الدواء</th><th>عدد الأيام</th><th>آخر استخدام</th></tr></thead>
                <tbody>
                  {Object.entries(summary).map(([name, info], i) => (
                    <tr key={i}>
                      <td><strong>💊 {name}</strong></td>
                      <td><span className="badge by">{info.count} يوم</span></td>
                      <td>{info.dates[info.dates.length - 1]}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="card">
            <div className="card-t">📅 سجل الأدوية يوم بيوم</div>
            <div style={{ overflowX: "auto" }}>
              <table className="tbl">
                <thead><tr><th>التاريخ</th><th>العمر</th><th>الدواء</th>{(onEditMed || onDeleteMed) && <th>إجراء</th>}</tr></thead>
                <tbody>
                  {allMeds.map((m, i) => (
                    <tr key={i}>
                      <td>{m.date}</td>
                      <td><span className="badge by">{m.age} يوم</span></td>
                      <td style={{ color: "#7b2d8b", fontWeight: 700 }}>💊 {m.name}</td>
                      {(onEditMed || onDeleteMed) && (
                        <td>
                          <div style={{ display: "flex", gap: 3 }}>
                            {onEditMed && <button className="btn btn-n btn-xs" onClick={() => setEditEntry({ ...m })}>✏️</button>}
                            {onDeleteMed && <button className="btn btn-d btn-xs" onClick={() => setConfirm({ msg: `هتمسح دواء "${m.name}" من يوم ${m.date}؟`, fn: () => onDeleteMed(m.recordId, m.id) })}>🗑️</button>}
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ========== DAY SUMMARY TAB ==========// ========== DAY SUMMARY TAB ==========
function DaySummaryTab({ session }) {
  const today = new Date().toISOString().split("T")[0];
  const [date, setDate] = useState(today);
  const record = (session.dailyRecords || []).find(r => r.date === date);
  const age = session.startDate && date ? Math.floor((new Date(date) - new Date(session.startDate)) / 86400000) : "-";

  return (
    <div>
      <div className="fg" style={{ maxWidth: 200, marginBottom: 14 }}>
        <label className="lbl">📅 التاريخ</label>
        <input className="inp" type="date" value={date} onChange={e => setDate(e.target.value)} />
      </div>
      {!record ? (
        <div className="empty"><div className="ico">📭</div><p>لم يتم التسجيل في هذا اليوم</p></div>
      ) : (
        <>
          <div style={{ marginBottom: 12 }}>
            <span className="badge by" style={{ fontSize: 13, padding: "4px 14px" }}>عمر الدورة: {age} يوم</span>
          </div>
          <div className="shift-wrap">
            <div className="card" style={{ margin: 0 }}>
              <div className="card-t night">🌙 شفت الليل</div>
              <div className="stats" style={{ marginBottom: 0 }}>
                <div className="stat"><div className="sv cr">{record.night.mortality || 0}</div><div className="sl">نافق الليل</div></div>
                <div className="stat"><div className="sv cy">{record.night.feed || 0} كجم</div><div className="sl">علف الليل</div></div>
              </div>
            </div>
            <div className="card" style={{ margin: 0 }}>
              <div className="card-t day">☀️ شفت النهار</div>
              <div className="stats" style={{ marginBottom: 0 }}>
                <div className="stat"><div className="sv cr">{record.day.mortality || 0}</div><div className="sl">نافق النهار</div></div>
                <div className="stat"><div className="sv cy">{record.day.feed || 0} كجم</div><div className="sl">علف النهار</div></div>
              </div>
            </div>
          </div>
          <div className="card" style={{ marginTop: 12 }}>
            <div className="card-t">📊 إجمالي اليوم</div>
            <div className="stats" style={{ marginBottom: 0 }}>
              <div className="stat"><div className="sv cr">{num(record.night.mortality) + num(record.day.mortality)}</div><div className="sl">إجمالي النافق</div></div>
              <div className="stat"><div className="sv cy">{num(record.night.feed) + num(record.day.feed)} كجم</div><div className="sl">إجمالي العلف</div></div>
            </div>
          </div>
          {(record.medicines || []).length > 0 && (
            <div className="card">
              <div className="card-t">💊 الأدوية</div>
              <table className="tbl">
                <thead><tr><th>الدواء</th><th>جرعة الليل</th><th>جرعة النهار</th><th>السبب</th></tr></thead>
                <tbody>
                  {record.medicines.map((m, i) => (
                    <tr key={i}><td style={{ fontWeight: 700 }}>💊 {m.name}</td><td>{m.dose12h || "-"}</td><td>{m.dose24h || "-"}</td><td>{m.reason || "-"}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ========== SUMMARY TAB ==========
function SummaryTab({ session }) {
  const totalMort = (session.dailyRecords || []).reduce((s, r) => s + calcDayStats(r).mortality, 0);
  const totalFeed = (session.dailyRecords || []).reduce((s, r) => s + calcDayStats(r).feed, 0);
  const remaining = num(session.birdCount) - totalMort;
  const mortRate = session.birdCount ? ((totalMort / num(session.birdCount)) * 100).toFixed(2) : 0;
  const age = calcAge(session.startDate);
  const lastW = (session.weeklyWeights || []).slice(-1)[0];
  const fcr = lastW ? calcFCR(totalFeed, num(lastW.avgWeight), remaining) : "-";

  return (
    <div className="card">
      <div className="card-t">📊 ملخص الدورة</div>
      <div className="stats">
        <div className="stat"><div className="sv cy">{age}</div><div className="sl">عمر الدورة (يوم)</div></div>
        <div className="stat"><div className="sv cg">{remaining.toLocaleString()}</div><div className="sl">الطيور الحالية</div></div>
        <div className="stat"><div className="sv cr">{totalMort.toLocaleString()}</div><div className="sl">إجمالي النافق</div></div>
        <div className="stat"><div className="sv cr">{mortRate}%</div><div className="sl">نسبة النفق</div></div>
        <div className="stat"><div className="sv cy">{totalFeed.toFixed(0)} كجم</div><div className="sl">إجمالي العلف</div></div>
        <div className="stat"><div className="sv cp">{fcr}</div><div className="sl">FCR</div></div>
        {lastW && <div className="stat"><div className="sv cg">{lastW.avgWeight} جم</div><div className="sl">آخر متوسط وزن</div></div>}
      </div>
    </div>
  );
}

// ========== SITE STORE (FEED) ==========
function SiteStorePage({ siteId, data, onUpdate, isAdmin, currentUser, onBack }) {
  const canEdit = !!onUpdate;
  const site = SITES.find(s => s.id === siteId);
  const siteData = data?.sites?.[siteId] || { feedStore: { received: [], dispatched: [] } };
  const store = siteData.feedStore || { received: [], dispatched: [] };
  const [recForm, setRecForm] = useState({ date: new Date().toISOString().split("T")[0], item: "", qty: "", notes: "" });
  const [dispForm, setDispForm] = useState({ date: new Date().toISOString().split("T")[0], barn: site.barns[0], item: "", qty: "" });
  const [editRec, setEditRec] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [saved, setSaved] = useState("");
  const [showReport, setShowReport] = useState(false);

  const totalIn = store.received.reduce((s, r) => s + num(r.qty), 0);
  const totalOut = store.dispatched.reduce((s, r) => s + num(r.qty), 0);
  const balance = totalIn - totalOut;

  const deepUpdate = (newStore) => {
    if (!onUpdate) return;
    const d = JSON.parse(JSON.stringify(data));
    if (!d.sites[siteId]) return;
    d.sites[siteId].feedStore = newStore;
    onUpdate(d);
  };

  const addRec = (type, form, reset) => {
    if (!form.qty || !canEdit) return;
    deepUpdate({ ...store, [type]: [...store[type], { id: genId(), ...form }] });
    setSaved(type); setTimeout(() => setSaved(""), 2000); reset();
  };

  const deleteEntry = (type, id) => {
    setConfirm({ msg: "هتمسح السجل ده؟", fn: () => deepUpdate({ ...store, [type]: store[type].filter(r => r.id !== id) }) });
  };

  const saveEdit = () => {
    if (!editRec) return;
    const type = editRec._type;
    deepUpdate({ ...store, [type]: store[type].map(r => r.id === editRec.id ? editRec : r) });
    setEditRec(null);
  };

  const allRows = [...store.received.map(r => ({ ...r, _type: "received" })), ...store.dispatched.map(r => ({ ...r, _type: "dispatched" }))].sort((a, b) => a.date > b.date ? 1 : -1);
  const barnBalance = site.barns.map(b => ({ barn: b, total: store.dispatched.filter(r => r.barn === b).reduce((s, r) => s + num(r.qty), 0) }));

  // إجمالي الأصناف المتشابهة (مجمّعة بالاسم)
  const itemTotals = {};
  store.received.forEach(r => {
    const key = (r.item || "بدون اسم").trim();
    if (!itemTotals[key]) itemTotals[key] = { in: 0, out: 0 };
    itemTotals[key].in += num(r.qty);
  });
  store.dispatched.forEach(r => {
    const key = (r.item || "بدون اسم").trim();
    if (!itemTotals[key]) itemTotals[key] = { in: 0, out: 0 };
    itemTotals[key].out += num(r.qty);
  });
  const itemTotalsList = Object.entries(itemTotals).map(([name, v]) => ({ name, in: v.in, out: v.out, balance: v.in - v.out }));

  return (
    <div>
      {confirm && <Confirm msg={confirm.msg} onOk={() => { confirm.fn(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}
      {editRec && (
        <div className="modal-bg">
          <div className="modal">
            <div className="modal-t">✏️ تعديل السجل</div>
            <div className="g2" style={{ marginBottom: 12 }}>
              <div className="fg"><label className="lbl">التاريخ</label><input className="inp" type="date" value={editRec.date} onChange={e => setEditRec(p => ({ ...p, date: e.target.value }))} /></div>
              {editRec._type === "dispatched" && <div className="fg"><label className="lbl">العنبر</label><select className="inp" value={editRec.barn} onChange={e => setEditRec(p => ({ ...p, barn: e.target.value }))}>{site.barns.map(b => <option key={b}>{b}</option>)}</select></div>}
              <div className="fg"><label className="lbl">الصنف</label><input className="inp" value={editRec.item || ""} onChange={e => setEditRec(p => ({ ...p, item: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">الكمية</label><input className="inp" type="number" value={editRec.qty} onChange={e => setEditRec(p => ({ ...p, qty: e.target.value }))} /></div>
            </div>
            <div style={{ display: "flex", gap: 8 }}><button className="btn btn-n" style={{ flex: 1 }} onClick={() => setEditRec(null)}>إلغاء</button><button className="btn btn-p" style={{ flex: 1 }} onClick={saveEdit}>💾 حفظ</button></div>
          </div>
        </div>
      )}

      {showReport && (
        <SimpleReport
          title="تقرير مخزن العلف"
          badge={`الموقع: ${site.name}`}
          currentUser={currentUser}
          onClose={() => setShowReport(false)}
          sections={
            <>
              <div className="a4sechead">ملخص المخزن</div>
              <div className="a4stats">
                <div className="a4box"><div className="v">+{totalIn.toFixed(0)} كجم</div><div className="l">إجمالي الوارد</div></div>
                <div className="a4box"><div className="v">-{totalOut.toFixed(0)} كجم</div><div className="l">إجمالي الصادر</div></div>
                <div className="a4box"><div className="v">{balance.toFixed(0)} كجم</div><div className="l">الرصيد الحالي</div></div>
              </div>
              <div className="a4sechead">إجمالي الأصناف المتشابهة</div>
              <table className="a4tbl">
                <thead><tr><th>الصنف</th><th>إجمالي الوارد</th><th>إجمالي الصادر</th><th>الرصيد</th></tr></thead>
                <tbody>
                  {itemTotalsList.map((it, i) => (
                    <tr key={i}><td><strong>{it.name}</strong></td><td>+{it.in.toFixed(0)}</td><td>-{it.out.toFixed(0)}</td><td><strong>{it.balance.toFixed(0)}</strong></td></tr>
                  ))}
                </tbody>
              </table>
              <div className="a4sechead">سجل المخزن</div>
              <table className="a4tbl">
                <thead><tr><th>التاريخ</th><th>النوع</th><th>العنبر</th><th>الصنف</th><th>وارد</th><th>صادر</th></tr></thead>
                <tbody>
                  {allRows.map((r, i) => (
                    <tr key={i}><td>{r.date}</td><td>{r._type === "received" ? "وارد" : "صرف"}</td><td>{r.barn || "-"}</td><td>{r.item || "-"}</td><td>{r._type === "received" ? `+${r.qty}` : ""}</td><td>{r._type === "dispatched" ? `-${r.qty}` : ""}</td></tr>
                  ))}
                </tbody>
              </table>
            </>
          }
        />
      )}

      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 2, flexWrap: "wrap" }}>
        <button className="btn btn-n btn-sm" onClick={onBack}>← رجوع</button>
        <div className="pg-title" style={{ margin: 0 }}>🌾 مخزن علف {site.name}</div>
        <button className="btn btn-n btn-sm" style={{ marginRight: "auto" }} onClick={() => setShowReport(true)}>🖨️ طباعة تقرير</button>
      </div>
      <div className="pg-sub">مخزن مشترك لكل العنابر — يُسحب منه تلقائياً عند تسجيل العلف اليومي</div>

      <div className="stats">
        <div className="stat"><div className="sv cg">+{totalIn.toFixed(0)}</div><div className="sl">إجمالي الوارد</div></div>
        <div className="stat"><div className="sv cr">-{totalOut.toFixed(0)}</div><div className="sl">إجمالي الصادر</div></div>
        <div className="stat"><div className="sv" style={{ color: balance >= 0 ? C.green : C.red }}>{balance.toFixed(0)}</div><div className="sl">الرصيد</div></div>
      </div>

      <div className="card">
        <div className="card-t">📦 صرف على العنابر</div>
        <div className="stats" style={{ marginBottom: 0 }}>
          {barnBalance.map(b => <div className="stat" key={b.barn}><div className="sv cr">{b.total.toFixed(0)}</div><div className="sl">{b.barn}</div></div>)}
        </div>
      </div>

      {itemTotalsList.length > 0 && (
        <div className="card">
          <div className="card-t">🧮 إجمالي الأصناف المتشابهة</div>
          <div style={{ overflowX: "auto" }}>
            <table className="tbl">
              <thead><tr><th>الصنف</th><th>إجمالي الوارد</th><th>إجمالي الصادر</th><th>الرصيد</th></tr></thead>
              <tbody>
                {itemTotalsList.map((it, i) => (
                  <tr key={i}>
                    <td style={{ fontWeight: 700 }}>{it.name}</td>
                    <td style={{ color: C.green }}>+{it.in.toFixed(0)}</td>
                    <td style={{ color: C.red }}>-{it.out.toFixed(0)}</td>
                    <td><span className="badge by">{it.balance.toFixed(0)} كجم</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {canEdit && (
        <>
          <div className="card">
            <div className="card-t">📥 إضافة وارد</div>
            {saved === "received" && <div className="alert alert-ok">✅ تم</div>}
            <div className="g4">
              <div className="fg"><label className="lbl">التاريخ</label><input className="inp" type="date" value={recForm.date} onChange={e => setRecForm(p => ({ ...p, date: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">الصنف</label><input className="inp" value={recForm.item} onChange={e => setRecForm(p => ({ ...p, item: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">الكمية (كجم)</label><input className="inp" type="number" value={recForm.qty} onChange={e => setRecForm(p => ({ ...p, qty: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">ملاحظات</label><input className="inp" value={recForm.notes} onChange={e => setRecForm(p => ({ ...p, notes: e.target.value }))} /></div>
            </div>
            <button className="btn btn-s btn-sm" style={{ marginTop: 10 }} onClick={() => addRec("received", recForm, () => setRecForm(p => ({ ...p, item: "", qty: "", notes: "" })))}>+ وارد</button>
          </div>

          <div className="card">
            <div className="card-t">📤 صرف لعنبر (يدوي)</div>
            {saved === "dispatched" && <div className="alert alert-ok">✅ تم الصرف</div>}
            <div className="g4">
              <div className="fg"><label className="lbl">التاريخ</label><input className="inp" type="date" value={dispForm.date} onChange={e => setDispForm(p => ({ ...p, date: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">العنبر</label><select className="inp" value={dispForm.barn} onChange={e => setDispForm(p => ({ ...p, barn: e.target.value }))}>{site.barns.map(b => <option key={b}>{b}</option>)}</select></div>
              <div className="fg"><label className="lbl">الصنف</label><input className="inp" value={dispForm.item} onChange={e => setDispForm(p => ({ ...p, item: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">الكمية (كجم)</label><input className="inp" type="number" value={dispForm.qty} onChange={e => setDispForm(p => ({ ...p, qty: e.target.value }))} /></div>
            </div>
            <button className="btn btn-d btn-sm" style={{ marginTop: 10 }} onClick={() => addRec("dispatched", dispForm, () => setDispForm(p => ({ ...p, item: "", qty: "" })))}>📤 صرف</button>
          </div>
        </>
      )}

      {allRows.length > 0 && (
        <div className="card">
          <div className="card-t">📋 سجل المخزن</div>
          <div style={{ overflowX: "auto" }}>
            <table className="tbl">
              <thead><tr><th>التاريخ</th><th>النوع</th><th>العنبر</th><th>الصنف</th><th>وارد</th><th>صادر</th>{canEdit && <th>إجراء</th>}</tr></thead>
              <tbody>
                {allRows.map(r => (
                  <tr key={r.id}>
                    <td>{r.date}</td>
                    <td>{r._type === "received" ? <span className="badge bg">وارد</span> : <span className="badge br">صرف</span>}</td>
                    <td>{r.barn || "-"}</td>
                    <td>{r.item || "-"}</td>
                    <td style={{ color: C.green }}>{r._type === "received" ? `+${r.qty}` : ""}</td>
                    <td style={{ color: C.red }}>{r._type === "dispatched" ? `-${r.qty}` : ""}</td>
                    {canEdit && <td><div style={{ display: "flex", gap: 3 }}><button className="btn btn-n btn-xs" onClick={() => setEditRec({ ...r })}>✏️</button>{isAdmin && <button className="btn btn-d btn-xs" onClick={() => deleteEntry(r._type, r.id)}>🗑️</button>}</div></td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ========== MEDICINE STORE ==========
function MedStorePage({ siteId, data, onUpdate, isAdmin, currentUser, onBack }) {
  const canEdit = !!onUpdate;
  const site = SITES.find(s => s.id === siteId);
  const medStore = data?.sites?.[siteId]?.medStore || { received: [] };
  const receivedList = medStore.received || [];
  const [form, setForm] = useState({ date: new Date().toISOString().split("T")[0], name: "", qty: "", unit: "مل", notes: "" });
  const [editRec, setEditRec] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [saved, setSaved] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [search, setSearch] = useState("");

  const deepUpdate = (newReceived) => {
    if (!onUpdate) return;
    const d = JSON.parse(JSON.stringify(data));
    if (!d.sites[siteId]) return;
    d.sites[siteId].medStore = { received: newReceived };
    onUpdate(d);
  };

  const addRec = () => {
    if (!form.name || !form.qty || !canEdit) return;
    deepUpdate([...receivedList, { id: genId(), ...form }]);
    setSaved(true); setTimeout(() => setSaved(false), 2000);
    setForm(p => ({ ...p, name: "", qty: "", notes: "" }));
  };

  const saveEdit = () => {
    if (!editRec) return;
    deepUpdate(receivedList.map(r => r.id === editRec.id ? editRec : r));
    setEditRec(null);
  };

  const deleteEntry = (id) => {
    setConfirm({ msg: "هتمسح السجل ده؟", fn: () => deepUpdate(receivedList.filter(r => r.id !== id)) });
  };

  // إجمالي كل صنف (رصيد تراكمي وارد فقط)
  const itemTotals = {};
  receivedList.forEach(r => {
    const key = (r.name || "بدون اسم").trim();
    if (!itemTotals[key]) itemTotals[key] = { total: 0, unit: r.unit || "" };
    itemTotals[key].total += num(r.qty);
  });
  const itemTotalsList = Object.entries(itemTotals).map(([name, v]) => ({ name, total: v.total, unit: v.unit }));

  const filteredTotals = itemTotalsList.filter(it => !search || it.name.toLowerCase().includes(search.toLowerCase()));
  const filteredRows = [...receivedList].filter(r => !search || (r.name || "").toLowerCase().includes(search.toLowerCase())).sort((a, b) => a.date > b.date ? 1 : -1);

  return (
    <div>
      {confirm && <Confirm msg={confirm.msg} onOk={() => { confirm.fn(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}
      {editRec && (
        <div className="modal-bg">
          <div className="modal">
            <div className="modal-t">✏️ تعديل السجل</div>
            <div className="g2" style={{ marginBottom: 12 }}>
              <div className="fg"><label className="lbl">التاريخ</label><input className="inp" type="date" value={editRec.date} onChange={e => setEditRec(p => ({ ...p, date: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">اسم الدواء</label><input className="inp" value={editRec.name} onChange={e => setEditRec(p => ({ ...p, name: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">الكمية</label><input className="inp" type="number" value={editRec.qty} onChange={e => setEditRec(p => ({ ...p, qty: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">الوحدة</label><select className="inp" value={editRec.unit} onChange={e => setEditRec(p => ({ ...p, unit: e.target.value }))}><option value="مل">مل</option><option value="جم">جم</option><option value="كجم">كجم</option><option value="لتر">لتر</option><option value="عبوة">عبوة</option></select></div>
              <div className="fg"><label className="lbl">ملاحظات</label><input className="inp" value={editRec.notes || ""} onChange={e => setEditRec(p => ({ ...p, notes: e.target.value }))} /></div>
            </div>
            <div style={{ display: "flex", gap: 8 }}><button className="btn btn-n" style={{ flex: 1 }} onClick={() => setEditRec(null)}>إلغاء</button><button className="btn btn-p" style={{ flex: 1 }} onClick={saveEdit}>💾 حفظ</button></div>
          </div>
        </div>
      )}

      {showReport && (
        <SimpleReport
          title="تقرير مخزن الدواء"
          badge={`الموقع: ${site.name}`}
          currentUser={currentUser}
          onClose={() => setShowReport(false)}
          sections={
            <>
              <div className="a4sechead">إجمالي الأصناف</div>
              <table className="a4tbl">
                <thead><tr><th>الدواء</th><th>إجمالي الوارد</th><th>الوحدة</th></tr></thead>
                <tbody>{itemTotalsList.map((it, i) => (<tr key={i}><td><strong>{it.name}</strong></td><td>{it.total}</td><td>{it.unit}</td></tr>))}</tbody>
              </table>
              <div className="a4sechead">سجل الوارد</div>
              <table className="a4tbl">
                <thead><tr><th>التاريخ</th><th>الدواء</th><th>الكمية</th><th>الوحدة</th><th>ملاحظات</th></tr></thead>
                <tbody>{[...receivedList].sort((a, b) => a.date > b.date ? 1 : -1).map((r, i) => (<tr key={i}><td>{r.date}</td><td>{r.name}</td><td>{r.qty}</td><td>{r.unit}</td><td>{r.notes || "-"}</td></tr>))}</tbody>
              </table>
            </>
          }
        />
      )}

      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 2, flexWrap: "wrap" }}>
        <button className="btn btn-n btn-sm" onClick={onBack}>← رجوع</button>
        <div className="pg-title" style={{ margin: 0 }}>💊 مخزن دواء {site.name}</div>
        <button className="btn btn-n btn-sm" style={{ marginRight: "auto" }} onClick={() => setShowReport(true)}>🖨️ طباعة تقرير</button>
      </div>
      <div className="pg-sub">مخزن وارد فقط — رصيد تراكمي بالكمية</div>

      {saved && <div className="alert alert-ok">✅ تم</div>}

      {canEdit && (
        <div className="card">
          <div className="card-t">📥 إضافة وارد دواء</div>
          <div className="g3">
            <div className="fg"><label className="lbl">التاريخ</label><input className="inp" type="date" value={form.date} onChange={e => setForm(p => ({ ...p, date: e.target.value }))} /></div>
            <div className="fg"><label className="lbl">اسم الدواء</label><input className="inp" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></div>
            <div className="fg"><label className="lbl">الكمية</label><input className="inp" type="number" value={form.qty} onChange={e => setForm(p => ({ ...p, qty: e.target.value }))} /></div>
            <div className="fg"><label className="lbl">الوحدة</label><select className="inp" value={form.unit} onChange={e => setForm(p => ({ ...p, unit: e.target.value }))}><option value="مل">مل</option><option value="جم">جم</option><option value="كجم">كجم</option><option value="لتر">لتر</option><option value="عبوة">عبوة</option></select></div>
            <div className="fg"><label className="lbl">ملاحظات</label><input className="inp" value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} /></div>
          </div>
          <button className="btn btn-s btn-sm" style={{ marginTop: 10 }} onClick={addRec}>+ إضافة</button>
        </div>
      )}

      <div className="card">
        <div className="card-t">🧮 إجمالي الأصناف</div>
        <div className="fg" style={{ maxWidth: 280, marginBottom: 12 }}>
          <label className="lbl">🔍 بحث عن صنف</label>
          <input className="inp" placeholder="اكتب اسم الدواء..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        {filteredTotals.length === 0 ? (
          <div className="empty"><div className="ico">💊</div><p>{search ? "لا توجد نتائج مطابقة" : "لا توجد أدوية في المخزن"}</p></div>
        ) : (
          <table className="tbl">
            <thead><tr><th>الدواء</th><th>إجمالي الكمية</th><th>الوحدة</th></tr></thead>
            <tbody>
              {filteredTotals.map((it, i) => (
                <tr key={i}><td style={{ fontWeight: 700 }}>💊 {it.name}</td><td><span className="badge by">{it.total}</span></td><td>{it.unit}</td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {filteredRows.length > 0 && (
        <div className="card">
          <div className="card-t">📋 سجل الوارد</div>
          <div style={{ overflowX: "auto" }}>
            <table className="tbl">
              <thead><tr><th>التاريخ</th><th>الدواء</th><th>الكمية</th><th>الوحدة</th><th>ملاحظات</th>{canEdit && <th>إجراء</th>}</tr></thead>
              <tbody>
                {filteredRows.map(r => (
                  <tr key={r.id}>
                    <td>{r.date}</td>
                    <td style={{ fontWeight: 700 }}>💊 {r.name}</td>
                    <td style={{ color: C.green }}>+{r.qty}</td>
                    <td>{r.unit}</td>
                    <td>{r.notes || "-"}</td>
                    {canEdit && <td><div style={{ display: "flex", gap: 3 }}><button className="btn btn-n btn-xs" onClick={() => setEditRec({ ...r })}>✏️</button>{isAdmin && <button className="btn btn-d btn-xs" onClick={() => deleteEntry(r.id)}>🗑️</button>}</div></td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ========== PRINT REPORT ==========
// ========== SIMPLE A4 REPORT (generic, for medicine/feed/gas store pages) ==========
function SimpleReport({ title, badge, currentUser, sections, onClose }) {
  const now = new Date();
  const reportNo = `${now.toISOString().split("T")[0].replace(/-/g, "")}-${Math.random().toString(36).slice(2, 6)}`;

  return (
    <div className="print-overlay" style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.85)", zIndex: 600, overflowY: "auto", padding: "14px 8px" }}>
      <style>{`
        @page { size: A4; margin: 10mm; }
        @media print {
          html, body { height: auto !important; overflow: visible !important; margin: 0 !important; padding: 0 !important; background: #fff !important; }
          body * { visibility: hidden !important; }
          .printable-report, .printable-report * { visibility: visible !important; }
          .print-overlay { position: static !important; inset: auto !important; overflow: visible !important; height: auto !important; padding: 0 !important; background: #fff !important; }
          .printable-report { position: static !important; width: 100% !important; max-width: none !important; margin: 0 !important; padding: 6mm 8mm !important; border: none !important; box-shadow: none !important; background: #fff !important; }
          .np { display: none !important; }
        }
        .a4page{background:#fff;color:#111;direction:rtl;font-family:Arial,Cairo,sans-serif;max-width:780px;margin:0 auto;padding:30px 34px;border:1px solid #000;box-shadow:0 0 0 1px #000}
        .a4head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #000;padding-bottom:14px;margin-bottom:14px}
        .a4title{font-size:19px;font-weight:800;text-align:center;flex:1}
        .a4sub{font-size:14px;font-weight:700;text-align:center;margin-top:2px}
        .a4badge{background:#000;color:#fff;padding:6px 18px;border-radius:6px;font-size:12px;font-weight:700;display:inline-block;margin:8px auto 14px;text-align:center}
        .a4meta{display:flex;justify-content:space-between;border-top:1px solid #000;border-bottom:1px solid #000;padding:10px 0;margin-bottom:16px;font-size:11px}
        .a4meta .mlabel{color:#444;font-size:10px}
        .a4meta .mval{font-weight:700;font-size:12px}
        .a4sechead{text-align:center;font-size:13px;font-weight:800;margin:18px 0 10px;position:relative}
        .a4sechead::before,.a4sechead::after{content:"";display:inline-block;width:60px;height:1px;background:#999;vertical-align:middle;margin:0 8px}
        .a4stats{display:flex;gap:10px;flex-wrap:wrap;justify-content:center;margin-bottom:6px}
        .a4box{border:1px solid #000;border-radius:8px;padding:12px 16px;text-align:center;min-width:110px;flex:1}
        .a4box .v{font-size:20px;font-weight:800}
        .a4box .l{font-size:10px;color:#444;margin-top:3px}
        .a4tbl{width:100%;border-collapse:collapse;margin-bottom:6px;font-size:11px}
        .a4tbl th{background:#f2f2f2;border:1px solid #000;padding:7px;font-weight:800}
        .a4tbl td{border:1px solid #000;padding:6px}
        .siggrid{display:flex;justify-content:space-between;margin-top:30px;padding-top:16px}
        .sigbox{text-align:center;width:45%}
        .sigline{border-bottom:1px solid #000;height:50px;margin-bottom:6px}
        .stampcircle{width:90px;height:90px;border:2px dashed #999;border-radius:50%;margin:0 auto 6px;display:flex;align-items:center;justify-content:center;color:#999;font-size:11px;text-align:center}
        .a4footer{text-align:center;font-size:10px;color:#666;margin-top:20px;border-top:1px solid #000;padding-top:8px}
      `}</style>

      <div className="np" style={{ display: "flex", gap: 10, justifyContent: "center", marginBottom: 12 }}>
        <button onClick={() => window.print()} style={{ padding: "8px 20px", background: "#1a73e8", color: "#fff", border: "none", borderRadius: 8, fontFamily: "Cairo", fontWeight: 700, cursor: "pointer" }}>🖨️ طباعة</button>
        <button onClick={onClose} style={{ padding: "8px 20px", background: "#eee", color: "#333", border: "none", borderRadius: 8, fontFamily: "Cairo", fontWeight: 700, cursor: "pointer" }}>✕ إغلاق</button>
      </div>

      <div className="a4page printable-report">
        <div className="a4head">
          <img src="/logo.png" alt="logo" style={{ width: 70, height: 70, objectFit: "contain" }} onError={e => { e.target.style.display = "none"; }} />
          <div style={{ flex: 1 }}>
            <div className="a4title">{title}</div>
            <div className="a4sub">مزارع أبوشريف</div>
          </div>
          <div style={{ width: 70 }} />
        </div>

        {badge && <div style={{ textAlign: "center" }}><span className="a4badge">{badge}</span></div>}

        <div className="a4meta">
          <div><div className="mlabel">رقم التقرير</div><div className="mval">{reportNo}</div></div>
          <div><div className="mlabel">اسم المستخدم</div><div className="mval">👤 {currentUser?.username || "-"}</div></div>
          <div><div className="mlabel">تاريخ ووقت الطباعة</div><div className="mval">{now.toLocaleDateString("en-GB")} {now.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}</div></div>
        </div>

        {sections}

        <div className="siggrid">
          <div className="sigbox">
            <div className="sigline" />
            <div style={{ fontWeight: 700, fontSize: 12 }}>توقيع مدير المزرعة</div>
          </div>
          <div className="sigbox">
            <div className="stampcircle">ختم<br />المدير</div>
          </div>
        </div>

        <div className="a4footer">مزارع أبوشريف | ABO SHERIF FARMS — تم إنشاء التقرير بتاريخ {now.toLocaleDateString("en-GB")} الساعة {now.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}</div>
      </div>
    </div>
  );
}

// ========== PRINT REPORT (PER BARN) ==========
function PrintReport({ session, siteName, barnName, currentUser, onClose }) {
  const totalMort = (session.dailyRecords || []).reduce((s, r) => s + calcDayStats(r).mortality, 0);
  const totalFeed = (session.dailyRecords || []).reduce((s, r) => s + calcDayStats(r).feed, 0);
  const remaining = num(session.birdCount) - totalMort;
  const mortRate = session.birdCount ? ((totalMort / num(session.birdCount)) * 100).toFixed(2) : 0;
  const age = calcAge(session.startDate);
  const lastW = (session.weeklyWeights || []).slice(-1)[0];
  const fcr = lastW ? calcFCR(totalFeed, num(lastW.avgWeight), remaining) : "-";
  const allMeds = (session.dailyRecords || []).flatMap(r => (r.medicines || []).map(m => ({ ...m, date: r.date, age: session.startDate ? Math.floor((new Date(r.date) - new Date(session.startDate)) / 86400000) : "-" })));
  const feedUpToWeek = (wk) => {
    const start = new Date(session.startDate);
    return (session.dailyRecords || []).filter(r => (new Date(r.date) - start) / 86400000 < wk * 7).reduce((s, r) => s + calcDayStats(r).feed, 0);
  };
  const now = new Date();
  const reportNo = `${now.toISOString().split("T")[0].replace(/-/g, "")}-${barnName ? barnName.replace(/\D/g, "") || "1" : "1"}`;

  return (
    <div className="print-overlay" style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.85)", zIndex: 600, overflowY: "auto", padding: "14px 8px" }}>
      <style>{`
        @page { size: A4; margin: 10mm; }
        @media print {
          html, body { height: auto !important; overflow: visible !important; margin: 0 !important; padding: 0 !important; background: #fff !important; }
          body * { visibility: hidden !important; }
          .printable-report, .printable-report * { visibility: visible !important; }
          .print-overlay { position: static !important; inset: auto !important; overflow: visible !important; height: auto !important; padding: 0 !important; background: #fff !important; }
          .printable-report { position: static !important; width: 100% !important; max-width: none !important; margin: 0 !important; padding: 6mm 8mm !important; border: none !important; box-shadow: none !important; background: #fff !important; }
          .np { display: none !important; }
        }
        .a4page{background:#fff;color:#111;direction:rtl;font-family:Arial,Cairo,sans-serif;max-width:780px;margin:0 auto;padding:30px 34px;border:1px solid #000;box-shadow:0 0 0 1px #000}
        .a4head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #000;padding-bottom:14px;margin-bottom:14px}
        .a4title{font-size:19px;font-weight:800;text-align:center;flex:1}
        .a4sub{font-size:14px;font-weight:700;text-align:center;margin-top:2px}
        .a4badge{background:#000;color:#fff;padding:6px 18px;border-radius:6px;font-size:12px;font-weight:700;display:inline-block;margin:8px auto 14px;text-align:center}
        .a4meta{display:flex;justify-content:space-between;border-top:1px solid #000;border-bottom:1px solid #000;padding:10px 0;margin-bottom:16px;font-size:11px}
        .a4meta .mlabel{color:#444;font-size:10px}
        .a4meta .mval{font-weight:700;font-size:12px}
        .a4sechead{text-align:center;font-size:13px;font-weight:800;margin:18px 0 10px;position:relative}
        .a4sechead::before,.a4sechead::after{content:"";display:inline-block;width:60px;height:1px;background:#999;vertical-align:middle;margin:0 8px}
        .a4stats{display:flex;gap:10px;flex-wrap:wrap;justify-content:center;margin-bottom:6px}
        .a4box{border:1px solid #000;border-radius:8px;padding:12px 16px;text-align:center;min-width:110px;flex:1}
        .a4box .v{font-size:20px;font-weight:800}
        .a4box .l{font-size:10px;color:#444;margin-top:3px}
        .a4tbl{width:100%;border-collapse:collapse;margin-bottom:6px;font-size:11px}
        .a4tbl th{background:#f2f2f2;border:1px solid #000;padding:7px;font-weight:800}
        .a4tbl td{border:1px solid #000;padding:6px}
        .siggrid{display:flex;justify-content:space-between;margin-top:30px;padding-top:16px}
        .sigbox{text-align:center;width:45%}
        .sigline{border-bottom:1px solid #000;height:50px;margin-bottom:6px;display:flex;align-items:flex-end;justify-content:center}
        .stampcircle{width:90px;height:90px;border:2px dashed #999;border-radius:50%;margin:0 auto 6px;display:flex;align-items:center;justify-content:center;color:#999;font-size:11px;text-align:center}
        .a4footer{text-align:center;font-size:10px;color:#666;margin-top:20px;border-top:1px solid #000;padding-top:8px}
      `}</style>
      <div className="np" style={{ display: "flex", gap: 10, justifyContent: "center", marginBottom: 12 }}>
        <button onClick={() => window.print()} style={{ padding: "8px 20px", background: "#1a73e8", color: "#fff", border: "none", borderRadius: 8, fontFamily: "Cairo", fontWeight: 700, cursor: "pointer" }}>🖨️ طباعة</button>
        <button onClick={onClose} style={{ padding: "8px 20px", background: "#eee", color: "#333", border: "none", borderRadius: 8, fontFamily: "Cairo", fontWeight: 700, cursor: "pointer" }}>✕ إغلاق</button>
      </div>

      <div className="a4page printable-report">
        <div className="a4head">
          <img src="/logo.png" alt="logo" style={{ width: 70, height: 70, objectFit: "contain" }} onError={e => { e.target.style.display = "none"; }} />
          <div style={{ flex: 1 }}>
            <div className="a4title">تقرير دورة تسمين</div>
            <div className="a4sub">مزارع أبوشريف</div>
          </div>
          <div style={{ width: 70 }} />
        </div>

        <div style={{ textAlign: "center" }}><span className="a4badge">العنبر: {barnName} — {siteName}</span></div>

        <div className="a4meta">
          <div><div className="mlabel">رقم التقرير</div><div className="mval">{reportNo}</div></div>
          <div><div className="mlabel">اسم المستخدم</div><div className="mval">👤 {currentUser?.username || "-"}</div></div>
          <div><div className="mlabel">تاريخ ووقت الطباعة</div><div className="mval">{now.toLocaleDateString("en-GB")} {now.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}</div></div>
        </div>

        <div className="a4sechead">ملخص الدورة</div>
        <div className="a4stats">
          <div className="a4box"><div className="v">{num(session.birdCount).toLocaleString()}</div><div className="l">الطيور الأولية</div></div>
          <div className="a4box"><div className="v">{remaining.toLocaleString()}</div><div className="l">الطيور الحالية</div></div>
          <div className="a4box"><div className="v">{totalMort.toLocaleString()}</div><div className="l">إجمالي النافق</div></div>
          <div className="a4box"><div className="v">{mortRate}%</div><div className="l">نسبة النفوق</div></div>
          <div className="a4box"><div className="v">{totalFeed.toFixed(0)} كجم</div><div className="l">إجمالي العلف</div></div>
          {lastW && <div className="a4box"><div className="v">{lastW.avgWeight} جم</div><div className="l">آخر متوسط وزن</div></div>}
          <div className="a4box"><div className="v">{fcr}</div><div className="l">FCR</div></div>
          <div className="a4box"><div className="v">{age} يوم</div><div className="l">عمر الدورة</div></div>
        </div>

        {(session.dailyRecords || []).length > 0 && (
          <>
            <div className="a4sechead">السجلات اليومية</div>
            <table className="a4tbl">
              <thead><tr><th>التاريخ</th><th>العمر</th><th>نافق ل</th><th>نافق ن</th><th>إج نافق</th><th>علف ل</th><th>علف ن</th><th>إج علف</th></tr></thead>
              <tbody>
                {(session.dailyRecords || []).map((r, i) => {
                  const s = calcDayStats(r);
                  const dayAge = session.startDate ? Math.floor((new Date(r.date) - new Date(session.startDate)) / 86400000) : "-";
                  return (<tr key={i}><td>{r.date}</td><td><strong>{dayAge}</strong></td><td>{r.night.mortality || 0}</td><td>{r.day.mortality || 0}</td><td><strong>{s.mortality}</strong></td><td>{r.night.feed || 0}</td><td>{r.day.feed || 0}</td><td><strong>{s.feed}</strong></td></tr>);
                })}
              </tbody>
            </table>
          </>
        )}

        {(session.weeklyWeights || []).length > 0 && (
          <>
            <div className="a4sechead">الوزن الأسبوعي ومعامل التحويل</div>
            <table className="a4tbl">
              <thead><tr><th>الأسبوع</th><th>متوسط الوزن</th><th>إجمالي العلف</th><th>FCR</th></tr></thead>
              <tbody>
                {(session.weeklyWeights || []).map((w, i) => {
                  const tf = feedUpToWeek(num(w.week));
                  const f = calcFCR(tf, num(w.avgWeight), remaining);
                  return (<tr key={i}><td>أسبوع {w.week}</td><td>{w.avgWeight} جم</td><td>{tf.toFixed(0)} كجم</td><td><strong>{f}</strong></td></tr>);
                })}
              </tbody>
            </table>
          </>
        )}

        {allMeds.length > 0 && (
          <>
            <div className="a4sechead">سجل الأدوية</div>
            <table className="a4tbl">
              <thead><tr><th>التاريخ</th><th>العمر</th><th>الدواء</th><th>الكمية</th><th>جرعة الليل</th><th>جرعة النهار</th><th>السبب</th></tr></thead>
              <tbody>{allMeds.map((m, i) => (<tr key={i}><td>{m.date}</td><td>{m.age}</td><td>{m.name}</td><td>{num(m.qty) > 0 ? `${m.qty} ${m.unit || ""}` : "-"}</td><td>{m.dose12h || "-"}</td><td>{m.dose24h || "-"}</td><td>{m.reason || "-"}</td></tr>))}</tbody>
            </table>
          </>
        )}

        <div className="siggrid">
          <div className="sigbox">
            <div className="sigline" />
            <div style={{ fontWeight: 700, fontSize: 12 }}>توقيع مدير المزرعة</div>
          </div>
          <div className="sigbox">
            <div className="stampcircle">ختم<br />المدير</div>
          </div>
        </div>

        <div className="a4footer">مزارع أبوشريف | ABO SHERIF FARMS — تم إنشاء التقرير بتاريخ {now.toLocaleDateString("en-GB")} الساعة {now.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}</div>
      </div>
    </div>
  );
}


// ========== START SESSION ==========
function StartSession({ barnName, siteName, onStart, onBack }) {
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [birds, setBirds] = useState("");
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
        <button className="btn btn-n btn-sm" onClick={onBack}>← رجوع</button>
        <div className="pg-title" style={{ margin: 0 }}>🐔 {barnName}</div>
      </div>
      <div className="pg-sub">{siteName}</div>
      <div className="empty">
        <div className="ico">🐣</div>
        <p style={{ marginBottom: 16, fontSize: 14, fontWeight: 700 }}>لا توجد دورة نشطة</p>
        {onStart ? (
          <div className="card" style={{ maxWidth: 360, margin: "0 auto", textAlign: "right" }}>
            <div className="card-t">🚀 بدء دورة جديدة</div>
            <div className="g2" style={{ marginBottom: 12 }}>
              <div className="fg"><label className="lbl">تاريخ البداية</label><input className="inp" type="date" value={date} onChange={e => setDate(e.target.value)} /></div>
              <div className="fg"><label className="lbl">عدد الطيور</label><input className="inp" type="number" placeholder="25000" value={birds} onChange={e => setBirds(e.target.value)} /></div>
            </div>
            <button className="btn btn-s" onClick={() => { if (date && birds) onStart(date, birds); }}>✅ بدء الدورة</button>
          </div>
        ) : (
          <p style={{ color: C.muted, fontSize: 13 }}>ليس لديك صلاحية بدء دورة جديدة</p>
        )}
      </div>
    </div>
  );
}

// ========== BARN PAGE ==========
function BarnPage({ siteId, barnName, data, onUpdate, canEdit, isAdmin, currentUser, onBack }) {
  const siteData = data?.sites?.[siteId] || { sessions: {}, archive: [], feedStore: { received: [], dispatched: [] } };
  const session = siteData?.sessions?.[barnName] || null;
  const [activeTab, setActiveTab] = useState("daySummary");
  const [confirmAct, setConfirmAct] = useState(null);
  const [showReport, setShowReport] = useState(false);
  const siteName = SITES.find(s => s.id === siteId)?.name;

  const deepUpdateSession = (val) => {
    if (!onUpdate) return;
    const d = JSON.parse(JSON.stringify(data));
    if (!d.sites) d.sites = {};
    if (!d.sites[siteId]) d.sites[siteId] = { sessions: {}, archive: [], feedStore: { received: [], dispatched: [] } };
    if (!d.sites[siteId].sessions) d.sites[siteId].sessions = {};
    d.sites[siteId].sessions[barnName] = val;
    onUpdate(d);
  };

  const startSession = (date, birds) => {
    const s = emptySession(barnName);
    s.startDate = date; s.birdCount = birds;
    deepUpdateSession(s);
  };

  // Saves a daily record AND atomically deducts feed/medicine stock in a single update
  const saveDailyRecord = (record) => {
    if (!onUpdate) return { ok: false, err: "لا تملك صلاحية" };
    const d = JSON.parse(JSON.stringify(data));
    if (!d.sites[siteId]) d.sites[siteId] = { sessions: {}, archive: [], feedStore: { received: [], dispatched: [] }, medStore: { received: [] } };
    const fs = d.sites[siteId].feedStore || { received: [], dispatched: [] };

    const totalFeedToday = num(record.night.feed) + num(record.day.feed);
    if (totalFeedToday > 0) {
      const totalIn = fs.received.reduce((s, r) => s + num(r.qty), 0);
      const totalOut = fs.dispatched.reduce((s, r) => s + num(r.qty), 0);
      const balance = totalIn - totalOut;
      if (balance < totalFeedToday) return { ok: false, err: "الكمية المتاحة في مخزن العلف غير كافية!" };
      fs.dispatched.push({ id: genId(), date: record.date, barn: barnName, item: "علف (استهلاك يومي)", qty: totalFeedToday });
    }

    d.sites[siteId].feedStore = fs;
    if (!d.sites[siteId].sessions) d.sites[siteId].sessions = {};
    const currentSession = d.sites[siteId].sessions[barnName] || session;
    d.sites[siteId].sessions[barnName] = { ...currentSession, dailyRecords: [...(currentSession.dailyRecords || []), record] };

    onUpdate(d);
    return { ok: true };
  };

  // Reverts feed stock when a daily record is deleted, and removes the record
  const deleteDailyRecord = (recordId) => {
    if (!onUpdate) return;
    const d = JSON.parse(JSON.stringify(data));
    const fs = d.sites[siteId].feedStore || { received: [], dispatched: [] };
    const rec = (session.dailyRecords || []).find(r => r.id === recordId);
    if (rec) {
      fs.dispatched = fs.dispatched.filter(x => !(x.barn === barnName && x.date === rec.date && x.item === "علف (استهلاك يومي)" && num(x.qty) === num(rec.night.feed) + num(rec.day.feed)));
    }
    d.sites[siteId].feedStore = fs;
    d.sites[siteId].sessions[barnName] = { ...session, dailyRecords: session.dailyRecords.filter(r => r.id !== recordId) };
    onUpdate(d);
  };

  // Edits a medicine entry's name inside a specific daily record (no stock tracking anymore)
  const editMedInRecord = (recordId, medId, newName) => {
    if (!onUpdate) return { ok: false, err: "لا تملك صلاحية" };
    const d = JSON.parse(JSON.stringify(data));
    const recs = d.sites[siteId].sessions[barnName].dailyRecords;
    const rec = recs.find(r => r.id === recordId);
    if (!rec) return { ok: false, err: "السجل غير موجود" };
    rec.medicines = (rec.medicines || []).map(m => m.id === medId ? { ...m, name: newName } : m);
    onUpdate(d);
    return { ok: true };
  };

  // Deletes a medicine entry from a daily record
  const deleteMedFromRecord = (recordId, medId) => {
    if (!onUpdate) return;
    const d = JSON.parse(JSON.stringify(data));
    const recs = d.sites[siteId].sessions[barnName].dailyRecords;
    const rec = recs.find(r => r.id === recordId);
    if (!rec) return;
    rec.medicines = (rec.medicines || []).filter(m => m.id !== medId);
    onUpdate(d);
  };

  if (!session) return <StartSession barnName={barnName} siteName={siteName} onStart={isAdmin ? startSession : null} onBack={onBack} />;


  return (
    <div>
      {confirmAct && <Confirm msg={confirmAct.msg} onOk={() => { confirmAct.fn(); setConfirmAct(null); }} onCancel={() => setConfirmAct(null)} />}
      {showReport && <PrintReport session={session} siteName={siteName} barnName={barnName} currentUser={currentUser} onClose={() => setShowReport(false)} />}

      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4, flexWrap: "wrap" }}>
        <button className="btn btn-n btn-sm" onClick={onBack}>← رجوع</button>
        <div className="pg-title" style={{ margin: 0 }}>🐔 {barnName}</div>
        <div className="pg-sub" style={{ margin: "0 0 0 4px" }}>{siteName}</div>
      </div>

      <div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap", alignItems: "center" }}>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 7, padding: "5px 12px", fontSize: 11 }}>📅 <strong style={{ color: C.accent }}>{session.startDate}</strong></div>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 7, padding: "5px 12px", fontSize: 11 }}>🐔 <strong style={{ color: C.green }}>{num(session.birdCount).toLocaleString()}</strong></div>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 7, padding: "5px 12px", fontSize: 11 }}>📆 <strong style={{ color: C.accent }}>{calcAge(session.startDate)} يوم</strong></div>
        <div style={{ marginRight: "auto", display: "flex", gap: 5 }}>
          <button className="btn btn-n btn-sm" onClick={() => setShowReport(true)}>🖨️ تقرير</button>
          {isAdmin && <button className="btn btn-w btn-sm" onClick={() => setConfirmAct({ msg: "هل تريد أرشفة الدورة؟", fn: () => {
            const d = JSON.parse(JSON.stringify(data));
            d.sites[siteId].archive = d.sites[siteId].archive || [];
            const fs = d.sites[siteId].feedStore || { received: [], dispatched: [] };
            const gs = d.sites[siteId].gasStore || { received: [] };
            const ms = d.sites[siteId].medStore || [];
            const feedSnapshot = (fs.dispatched || []).filter(r => r.barn === barnName);
            const startD = session.startDate ? new Date(session.startDate) : null;
            const endD = new Date();
            const gasSnapshot = (gs.received || []).filter(r => !startD || (new Date(r.date) >= startD && new Date(r.date) <= endD));
            const medSnapshot = (session.dailyRecords || []).flatMap(r => (r.medicines || []).map(m => ({ ...m, date: r.date })));
            d.sites[siteId].archive.push({
              ...session,
              archivedAt: new Date().toISOString(),
              feedSnapshot,
              gasSnapshot,
              medSnapshot,
            });
            d.sites[siteId].sessions[barnName] = null;
            onUpdate(d);
          } })}>📦 أرشفة</button>}
          {isAdmin && <button className="btn btn-d btn-sm" onClick={() => setConfirmAct({ msg: "⚠️ هتمسح الدورة نهائي!", fn: () => deepUpdateSession(null) })}>🗑️ حذف</button>}
        </div>
      </div>

      <div className="tabs">
        <button className={`tab ${activeTab === "daySummary" ? "active" : ""}`} onClick={() => setActiveTab("daySummary")}>📋 ملخص اليوم</button>
        <button className={`tab ${activeTab === "daily" ? "active" : ""}`} onClick={() => setActiveTab("daily")}>📅 التسجيل</button>
        <button className={`tab ${activeTab === "weight" ? "active" : ""}`} onClick={() => setActiveTab("weight")}>⚖️ الوزن</button>
        <button className={`tab ${activeTab === "medicine" ? "active" : ""}`} onClick={() => setActiveTab("medicine")}>💊 الدواء</button>
        <button className={`tab ${activeTab === "summary" ? "active" : ""}`} onClick={() => setActiveTab("summary")}>📊 ملخص الدورة</button>
      </div>

      {activeTab === "daySummary" && <DaySummaryTab session={session} />}
      {activeTab === "daily" && <DailyTab session={session} onUpdate={canEdit ? deepUpdateSession : null} feedStore={siteData.feedStore} medStore={siteData.medStore} onSaveRecord={canEdit ? saveDailyRecord : null} onDeleteRecord={isAdmin ? deleteDailyRecord : null} isAdmin={isAdmin} />}
      {activeTab === "weight" && <WeightTab session={session} onUpdate={canEdit ? deepUpdateSession : null} isAdmin={isAdmin} />}
      {activeTab === "medicine" && <MedicineTab session={session} onEditMed={canEdit ? editMedInRecord : null} onDeleteMed={isAdmin ? deleteMedFromRecord : null} barnName={barnName} siteName={siteName} currentUser={currentUser} />}
      {activeTab === "summary" && <SummaryTab session={session} />}
    </div>
  );
}

// ========== ARCHIVE PAGE ==========
function ArchivePage({ data, onUpdate, siteId, onBack }) {
  const [selectedArchive, setSelectedArchive] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const site = SITES.find(s => s.id === siteId);

  const allArchived = (data?.sites?.[siteId]?.archive || []).map((s, idx) => ({ ...s, siteName: site.name, siteId, idx }));

  const deleteArchive = (sid, idx) => {
    setConfirm({ msg: "هتمسح الدورة من الأرشيف نهائي؟", fn: () => {
      const d = JSON.parse(JSON.stringify(data));
      d.sites[sid].archive.splice(idx, 1);
      onUpdate(d); setSelectedArchive(null);
    }});
  };

  if (selectedArchive) {
    const s = allArchived.find(x => x.idx === selectedArchive.idx);
    if (!s) { setSelectedArchive(null); return null; }
    return (
      <div>
        {confirm && <Confirm msg={confirm.msg} onOk={() => { confirm.fn(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}
        <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 12, flexWrap: "wrap" }}>
          <button className="btn btn-n btn-sm" onClick={() => setSelectedArchive(null)}>← رجوع</button>
          <div className="pg-title" style={{ margin: 0 }}>📦 {s.barnName} — {s.siteName}</div>
          <div style={{ marginRight: "auto", display: "flex", gap: 6 }}>
            <button className="btn btn-d btn-sm" onClick={() => deleteArchive(s.siteId, s.idx)}>🗑️ حذف</button>
          </div>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 7, padding: "5px 12px", fontSize: 11 }}>📅 بداية: <strong>{s.startDate}</strong></div>
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 7, padding: "5px 12px", fontSize: 11 }}>📅 نهاية: <strong>{s.archivedAt?.split("T")[0]}</strong></div>
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 7, padding: "5px 12px", fontSize: 11 }}>🐔 طيور: <strong>{num(s.birdCount).toLocaleString()}</strong></div>
        </div>
        <SummaryTab session={s} />
        {(s.dailyRecords || []).length > 0 && (
          <div className="card">
            <div className="card-t">📅 السجلات اليومية</div>
            <div style={{ overflowX: "auto" }}>
              <table className="tbl">
                <thead><tr><th>التاريخ</th><th>العمر</th><th>إج نافق</th><th>إج علف</th></tr></thead>
                <tbody>{(s.dailyRecords || []).map((r, i) => {
                  const st = calcDayStats(r);
                  const dayAge = s.startDate ? Math.floor((new Date(r.date) - new Date(s.startDate)) / 86400000) : "-";
                  return (<tr key={i}><td>{r.date}</td><td><span className="badge by">{dayAge} يوم</span></td><td><span className="badge br">{st.mortality}</span></td><td><span className="badge by">{st.feed} كجم</span></td></tr>);
                })}</tbody>
              </table>
            </div>
          </div>
        )}
        <MedicineTab session={s} onEditMed={null} onDeleteMed={null} medStore={[]} />

        {(s.weeklyWeights || []).length > 0 && (
          <div className="card">
            <div className="card-t">⚖️ الوزن الأسبوعي</div>
            <div style={{ overflowX: "auto" }}>
              <table className="tbl">
                <thead><tr><th>التاريخ التقريبي</th><th>العمر (أسبوع)</th><th>متوسط الوزن</th><th>عدد العينة</th></tr></thead>
                <tbody>
                  {(s.weeklyWeights || []).map((w, i) => {
                    const approxDate = s.startDate ? new Date(new Date(s.startDate).getTime() + num(w.week) * 7 * 86400000).toISOString().split("T")[0] : "-";
                    return (<tr key={i}><td>{approxDate}</td><td><span className="badge by">أسبوع {w.week}</span></td><td style={{ color: C.accent, fontWeight: 700 }}>{w.avgWeight} جم</td><td>{w.sampleCount}</td></tr>);
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {(s.feedSnapshot || []).length > 0 && (
          <div className="card">
            <div className="card-t">🌾 مخزن العلف (وقت الأرشفة)</div>
            <div style={{ overflowX: "auto" }}>
              <table className="tbl">
                <thead><tr><th>التاريخ</th><th>العمر</th><th>الصنف</th><th>الكمية المصروفة</th></tr></thead>
                <tbody>
                  {(s.feedSnapshot || []).map((r, i) => {
                    const dayAge = s.startDate ? Math.floor((new Date(r.date) - new Date(s.startDate)) / 86400000) : "-";
                    return (<tr key={i}><td>{r.date}</td><td><span className="badge by">{dayAge} يوم</span></td><td>{r.item || "-"}</td><td style={{ color: C.red }}>-{r.qty} كجم</td></tr>);
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {(s.medSnapshot || []).length > 0 && (
          <div className="card">
            <div className="card-t">💊 الأدوية المستخدمة في الدورة</div>
            <div style={{ overflowX: "auto" }}>
              <table className="tbl">
                <thead><tr><th>التاريخ</th><th>العمر</th><th>الدواء</th></tr></thead>
                <tbody>
                  {(s.medSnapshot || []).map((m, i) => {
                    const dayAge = s.startDate ? Math.floor((new Date(m.date) - new Date(s.startDate)) / 86400000) : "-";
                    return (<tr key={i}><td>{m.date}</td><td><span className="badge by">{dayAge} يوم</span></td><td>💊 {m.name}</td></tr>);
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {(s.gasSnapshot || []).length > 0 && (
          <div className="card">
            <div className="card-t">🔥 خزان الجاز (خلال فترة الدورة)</div>
            <div style={{ overflowX: "auto" }}>
              <table className="tbl">
                <thead><tr><th>التاريخ</th><th>العمر</th><th>الكمية</th><th>ملاحظات</th></tr></thead>
                <tbody>
                  {(s.gasSnapshot || []).map((r, i) => {
                    const dayAge = s.startDate ? Math.floor((new Date(r.date) - new Date(s.startDate)) / 86400000) : "-";
                    return (<tr key={i}><td>{r.date}</td><td><span className="badge by">{dayAge} يوم</span></td><td style={{ color: C.green }}>+{r.qty} لتر</td><td>{r.notes || "-"}</td></tr>);
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div>
      {confirm && <Confirm msg={confirm.msg} onOk={() => { confirm.fn(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
        <button className="btn btn-n btn-sm" onClick={onBack}>← رجوع</button>
        <div className="pg-title" style={{ margin: 0 }}>📦 أرشيف {site.name}</div>
      </div>
      <div className="pg-sub">اضغط على دورة لعرض التفاصيل</div>
      {allArchived.length === 0 ? (
        <div className="empty"><div className="ico">📭</div><p>لا توجد دورات مؤرشفة في هذا الموقع</p></div>
      ) : allArchived.map(s => {
        const tm = (s.dailyRecords || []).reduce((x, r) => x + calcDayStats(r).mortality, 0);
        const tf = (s.dailyRecords || []).reduce((x, r) => x + calcDayStats(r).feed, 0);
        const age = s.startDate ? Math.round((new Date(s.archivedAt) - new Date(s.startDate)) / 86400000) : 0;
        return (
          <div key={s.idx} onClick={() => setSelectedArchive({ idx: s.idx })}
            style={{ background: C.card, borderRadius: 10, padding: 14, marginBottom: 10, border: `1px solid ${C.border}`, cursor: "pointer", transition: "all .2s" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 6 }}>
              <div>
                <div style={{ fontWeight: 700, marginBottom: 3, fontSize: 13 }}>🐔 {s.barnName}</div>
                <div style={{ fontSize: 11, color: C.muted }}>بداية: {s.startDate} | مدة: {age} يوم | طيور: {num(s.birdCount).toLocaleString()} | نافق: {tm} | علف: {tf} كجم</div>
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <span className="badge by">منتهية</span>
                <button className="btn btn-d btn-xs" onClick={e => { e.stopPropagation(); deleteArchive(s.siteId, s.idx); }}>🗑️</button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ========== SETTINGS PAGE ==========
function SettingsPage({ currentUser, data, onUpdate, onDataRestore }) {
  const isAdmin = currentUser?.role === "admin";
  const [activeTab, setActiveTab] = useState("backup");
  const [backups, setBackups] = useState([]);
  const [loadingBk, setLoadingBk] = useState(false);
  const [bkLabel, setBkLabel] = useState("");
  const [savingBk, setSavingBk] = useState(false);
  const [bkMsg, setBkMsg] = useState("");
  const [users, setUsers] = useState([]);
  const [loadingU, setLoadingU] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [newUser, setNewUser] = useState({ username: "", password: "", role: "viewer", can_edit: false, allowed_sites: [] });
  const [showNew, setShowNew] = useState(false);
  const [uMsg, setUMsg] = useState("");
  const [confirm, setConfirm] = useState(null);

  useEffect(() => {
    if (activeTab === "backup") { setLoadingBk(true); fetchBackups().then(b => { setBackups(Array.isArray(b) ? b : []); setLoadingBk(false); }); }
    if (activeTab === "users" && isAdmin) { setLoadingU(true); fetchUsers().then(u => { setUsers(Array.isArray(u) ? u : []); setLoadingU(false); }); }
  }, [activeTab]);

  const doSaveBk = async () => {
    setSavingBk(true);
    await saveBackup(data, bkLabel || `نسخة ${new Date().toLocaleString("ar-EG")}`);
    setBkLabel(""); setBkMsg("✅ تم حفظ النسخة"); setTimeout(() => setBkMsg(""), 3000);
    const b = await fetchBackups(); setBackups(Array.isArray(b) ? b : []);
    setSavingBk(false);
  };

  const doRestoreBk = (id) => {
    setConfirm({ msg: "هتستبدل كل البيانات الحالية؟", fn: async () => {
      const d = await restoreBackupById(id);
      if (d) { await saveData(d); onDataRestore(d); setBkMsg("✅ تم الاستعادة"); setTimeout(() => setBkMsg(""), 3000); }
    }});
  };

  const doSaveUser = async () => {
    if (!editUser?.username || !editUser?.password) return;
    await updateUser(editUser.id, { username: editUser.username, password: editUser.password, role: editUser.role, can_edit: editUser.can_edit, allowed_sites: editUser.allowed_sites || [] });
    setEditUser(null); setUMsg("✅ تم الحفظ"); setTimeout(() => setUMsg(""), 2000);
    fetchUsers().then(u => setUsers(Array.isArray(u) ? u : []));
  };

  const doCreateUser = async () => {
    if (!newUser.username || !newUser.password) return;
    await createUser(newUser);
    setNewUser({ username: "", password: "", role: "viewer", can_edit: false, allowed_sites: [] });
    setShowNew(false); setUMsg("✅ تم إضافة المستخدم"); setTimeout(() => setUMsg(""), 2000);
    fetchUsers().then(u => setUsers(Array.isArray(u) ? u : []));
  };

  const toggleSite = (u, setU, siteId) => {
    const sites = u.allowed_sites || [];
    setU(p => ({ ...p, allowed_sites: sites.includes(siteId) ? sites.filter(s => s !== siteId) : [...sites, siteId] }));
  };

  const UserForm = ({ u, setU, onSave, onCancel }) => (
    <div className="card" style={{ border: `1.5px solid ${C.accent}` }}>
      <div className="g2" style={{ marginBottom: 10 }}>
        <div className="fg"><label className="lbl">اسم المستخدم</label><input className="inp" value={u.username} onChange={e => setU(p => ({ ...p, username: e.target.value }))} /></div>
        <div className="fg"><label className="lbl">كلمة المرور</label><input className="inp" value={u.password} onChange={e => setU(p => ({ ...p, password: e.target.value }))} /></div>
        <div className="fg"><label className="lbl">الدور</label><select className="inp" value={u.role} onChange={e => setU(p => ({ ...p, role: e.target.value }))}>
          <option value="admin">مدير</option><option value="editor">محرر</option><option value="viewer">مشاهد</option>
        </select></div>
        <div className="fg"><label className="lbl">يقدر يعدل البيانات؟</label>
          <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
            <button className={`btn btn-sm ${u.can_edit ? "btn-s" : "btn-n"}`} onClick={() => setU(p => ({ ...p, can_edit: true }))}>✅ نعم</button>
            <button className={`btn btn-sm ${!u.can_edit ? "btn-d" : "btn-n"}`} onClick={() => setU(p => ({ ...p, can_edit: false }))}>❌ لا</button>
          </div>
        </div>
      </div>
      {u.role !== "admin" && (
        <div style={{ marginBottom: 10 }}>
          <div className="lbl" style={{ marginBottom: 6 }}>المواقع المسموحة (فاضية = كل المواقع)</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {SITES.map(s => (
              <button key={s.id} className={`btn btn-sm ${(u.allowed_sites || []).includes(s.id) ? "btn-p" : "btn-n"}`} onClick={() => toggleSite(u, setU, s.id)}>{s.name}</button>
            ))}
          </div>
        </div>
      )}
      <div style={{ display: "flex", gap: 8 }}>
        <button className="btn btn-n btn-sm" onClick={onCancel}>إلغاء</button>
        <button className="btn btn-p btn-sm" onClick={onSave}>💾 حفظ</button>
      </div>
    </div>
  );

  return (
    <div>
      {confirm && <Confirm msg={confirm.msg} onOk={async () => { await confirm.fn(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}
      <div className="pg-title">⚙️ الإعدادات</div>
      <div className="tabs">
        <button className={`tab ${activeTab === "backup" ? "active" : ""}`} onClick={() => setActiveTab("backup")}>💾 النسخ الاحتياطي</button>
        {isAdmin && <button className={`tab ${activeTab === "users" ? "active" : ""}`} onClick={() => setActiveTab("users")}>👥 المستخدمين</button>}
      </div>

      {activeTab === "backup" && (
        <div>
          {bkMsg && <div className="alert alert-ok">{bkMsg}</div>}
          <div className="card">
            <div className="card-t">☁️ حفظ نسخة على Supabase</div>
            <div className="g2" style={{ marginBottom: 10 }}>
              <div className="fg"><label className="lbl">اسم النسخة (اختياري)</label><input className="inp" placeholder="مثال: قبل التسليم" value={bkLabel} onChange={e => setBkLabel(e.target.value)} /></div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn btn-s btn-sm" onClick={doSaveBk} disabled={savingBk}>{savingBk ? "..." : "☁️ حفظ الآن"}</button>
              <button className="btn btn-n btn-sm" onClick={() => downloadBackup(data)}>⬇️ تنزيل JSON</button>
            </div>
          </div>
          <div className="card">
            <div className="card-t">📋 آخر النسخ</div>
            {loadingBk ? <div style={{ color: C.muted, fontSize: 12 }}>جاري التحميل...</div> :
              backups.length === 0 ? <div style={{ color: C.muted, fontSize: 12 }}>لا توجد نسخ بعد</div> :
              backups.map(b => (
                <div key={b.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${C.border}`, gap: 8, flexWrap: "wrap" }}>
                  <div><div style={{ fontSize: 12, fontWeight: 700 }}>💾 {b.label}</div><div style={{ fontSize: 10, color: C.muted }}>{new Date(b.created_at).toLocaleString("ar-EG")}</div></div>
                  <div style={{ display: "flex", gap: 5 }}>
                    <button className="btn btn-w btn-xs" onClick={() => doRestoreBk(b.id)}>↩️ استعادة</button>
                    <button className="btn btn-d btn-xs" onClick={() => setConfirm({ msg: "هتمسح النسخة دي؟", fn: async () => { await deleteBackupById(b.id); const bks = await fetchBackups(); setBackups(Array.isArray(bks) ? bks : []); } })}>🗑️</button>
                  </div>
                </div>
              ))
            }
          </div>
          <div className="card">
            <div className="card-t">⬆️ استعادة من ملف</div>
            <label style={{ background: C.cardAlt, border: `1px solid ${C.border}`, borderRadius: 8, padding: "8px 16px", fontSize: 12, fontWeight: 700, cursor: "pointer", display: "inline-block", color: C.text }}>
              📂 اختر ملف JSON
              <input type="file" accept=".json" style={{ display: "none" }} onChange={e => {
                const file = e.target.files[0]; if (!file) return;
                setConfirm({ msg: "هتستبدل كل البيانات الحالية؟", fn: () => restoreBackup(file, d => { onDataRestore(d); setBkMsg("✅ تم الاستعادة"); setTimeout(() => setBkMsg(""), 3000); }) });
              }} />
            </label>
          </div>
        </div>
      )}

      {activeTab === "users" && isAdmin && (
        <div>
          {uMsg && <div className="alert alert-ok">{uMsg}</div>}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <div style={{ fontSize: 13, fontWeight: 700 }}>إجمالي: {users.length} مستخدمين</div>
            <button className="btn btn-s btn-sm" onClick={() => { setShowNew(true); setEditUser(null); }}>+ إضافة مستخدم</button>
          </div>
          {showNew && <UserForm u={newUser} setU={setNewUser} onSave={doCreateUser} onCancel={() => setShowNew(false)} />}
          {loadingU ? <div style={{ color: C.muted }}>جاري التحميل...</div> :
            users.map(u => (
              <div key={u.id}>
                {editUser?.id === u.id ? (
                  <UserForm u={editUser} setU={setEditUser} onSave={doSaveUser} onCancel={() => setEditUser(null)} />
                ) : (
                  <div style={{ background: C.cardAlt, borderRadius: 10, padding: 12, marginBottom: 8, border: `1px solid ${C.border}` }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 6 }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 13 }}>👤 {u.username}</div>
                        <div style={{ fontSize: 11, color: C.muted, marginTop: 2 }}>
                          <span className={`badge ${u.role === "admin" ? "by" : u.role === "editor" ? "bb" : "bg"}`}>{u.role === "admin" ? "مدير" : u.role === "editor" ? "محرر" : "مشاهد"}</span>
                          {" "}{u.can_edit ? <span className="badge bg">يعدل</span> : <span className="badge br">مشاهدة فقط</span>}
                          {(u.allowed_sites || []).length > 0 && <span style={{ marginRight: 6 }}>| {(u.allowed_sites || []).map(id => SITES.find(s => s.id === id)?.name).join("، ")}</span>}
                        </div>
                      </div>
                      <div style={{ display: "flex", gap: 5 }}>
                        <button className="btn btn-n btn-xs" onClick={() => { setEditUser({ ...u }); setShowNew(false); }}>✏️</button>
                        {u.username !== currentUser.username && <button className="btn btn-d btn-xs" onClick={() => setConfirm({ msg: "هتمسح المستخدم ده؟", fn: async () => { await deleteUser(u.id); fetchUsers().then(us => setUsers(Array.isArray(us) ? us : [])); } })}>🗑️</button>}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))
          }
        </div>
      )}
    </div>
  );
}

// ========== SITE REPORT ==========
function SiteReport({ siteId, data, currentUser, onClose }) {
  const site = SITES.find(s => s.id === siteId);
  const siteData = data?.sites?.[siteId] || { sessions: {}, feedStore: { received: [], dispatched: [] } };

  const barnStats = site.barns.map(barn => {
    const session = siteData?.sessions?.[barn];
    if (!session) return { barn, hasSession: false, birds: 0, feed: 0, mortality: 0, birdsStart: 0 };
    const totalMort = (session.dailyRecords || []).reduce((s, r) => s + calcDayStats(r).mortality, 0);
    const totalFeed = (session.dailyRecords || []).reduce((s, r) => s + calcDayStats(r).feed, 0);
    const remaining = num(session.birdCount) - totalMort;
    return { barn, hasSession: true, birds: remaining, birdsStart: num(session.birdCount), feed: totalFeed, mortality: totalMort, startDate: session.startDate, age: calcAge(session.startDate) };
  });

  const totalBirdsStart = barnStats.reduce((s, b) => s + b.birdsStart, 0);
  const totalBirds = barnStats.reduce((s, b) => s + b.birds, 0);
  const totalMortAll = barnStats.reduce((s, b) => s + b.mortality, 0);
  const mortRateAll = totalBirdsStart ? ((totalMortAll / totalBirdsStart) * 100).toFixed(2) : "0.00";
  const totalFeedConsumed = barnStats.reduce((s, b) => s + b.feed, 0);
  const totalFeedIn = (siteData.feedStore?.received || []).reduce((s, r) => s + num(r.qty), 0);
  const gasBalance = (siteData.gasStore?.received || []).reduce((s, r) => s + num(r.qty), 0);
  const totalInjections = (siteData.injections || []).length;
  const activeBarns = barnStats.filter(b => b.hasSession).length;
  const now = new Date();
  const reportNo = `${now.toISOString().split("T")[0].replace(/-/g, "")}-${siteId}`;

  return (
    <div className="print-overlay" style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.85)", zIndex: 600, overflowY: "auto", padding: "14px 8px" }}>
      <style>{`
        @page { size: A4; margin: 10mm; }
        @media print {
          html, body { height: auto !important; overflow: visible !important; margin: 0 !important; padding: 0 !important; background: #fff !important; }
          body * { visibility: hidden !important; }
          .printable-report, .printable-report * { visibility: visible !important; }
          .print-overlay { position: static !important; inset: auto !important; overflow: visible !important; height: auto !important; padding: 0 !important; background: #fff !important; }
          .printable-report { position: static !important; width: 100% !important; max-width: none !important; margin: 0 !important; padding: 6mm 8mm !important; border: none !important; box-shadow: none !important; background: #fff !important; }
          .np { display: none !important; }
        }
        .a4page{background:#fff;color:#111;direction:rtl;font-family:Arial,Cairo,sans-serif;max-width:780px;margin:0 auto;padding:30px 34px;border:1px solid #000;box-shadow:0 0 0 1px #000}
        .a4head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #000;padding-bottom:14px;margin-bottom:14px}
        .a4title{font-size:19px;font-weight:800;text-align:center;flex:1}
        .a4sub{font-size:14px;font-weight:700;text-align:center;margin-top:2px}
        .a4badge{background:#000;color:#fff;padding:6px 18px;border-radius:6px;font-size:12px;font-weight:700;display:inline-block;margin:8px auto 14px;text-align:center}
        .a4meta{display:flex;justify-content:space-between;border-top:1px solid #000;border-bottom:1px solid #000;padding:10px 0;margin-bottom:16px;font-size:11px}
        .a4meta .mlabel{color:#444;font-size:10px}
        .a4meta .mval{font-weight:700;font-size:12px}
        .a4sechead{text-align:center;font-size:13px;font-weight:800;margin:18px 0 10px;position:relative}
        .a4sechead::before,.a4sechead::after{content:"";display:inline-block;width:60px;height:1px;background:#999;vertical-align:middle;margin:0 8px}
        .a4stats{display:flex;gap:10px;flex-wrap:wrap;justify-content:center;margin-bottom:6px}
        .a4box{border:1px solid #000;border-radius:8px;padding:12px 16px;text-align:center;min-width:110px;flex:1}
        .a4box .v{font-size:20px;font-weight:800}
        .a4box .l{font-size:10px;color:#444;margin-top:3px}
        .a4tbl{width:100%;border-collapse:collapse;margin-bottom:6px;font-size:11px}
        .a4tbl th{background:#f2f2f2;border:1px solid #000;padding:7px;font-weight:800}
        .a4tbl td{border:1px solid #000;padding:6px}
        .siggrid{display:flex;justify-content:space-between;margin-top:30px;padding-top:16px}
        .sigbox{text-align:center;width:45%}
        .sigline{border-bottom:1px solid #000;height:50px;margin-bottom:6px}
        .stampcircle{width:90px;height:90px;border:2px dashed #999;border-radius:50%;margin:0 auto 6px;display:flex;align-items:center;justify-content:center;color:#999;font-size:11px;text-align:center}
        .a4footer{text-align:center;font-size:10px;color:#666;margin-top:20px;border-top:1px solid #000;padding-top:8px}
      `}</style>

      <div className="np" style={{ display: "flex", gap: 10, justifyContent: "center", marginBottom: 12 }}>
        <button onClick={() => window.print()} style={{ padding: "8px 20px", background: "#1a73e8", color: "#fff", border: "none", borderRadius: 8, fontFamily: "Cairo", fontWeight: 700, cursor: "pointer" }}>🖨️ طباعة</button>
        <button onClick={onClose} style={{ padding: "8px 20px", background: "#eee", color: "#333", border: "none", borderRadius: 8, fontFamily: "Cairo", fontWeight: 700, cursor: "pointer" }}>✕ إغلاق</button>
      </div>

      <div className="a4page printable-report">
        <div className="a4head">
          <img src="/logo.png" alt="logo" style={{ width: 70, height: 70, objectFit: "contain" }} onError={e => { e.target.style.display = "none"; }} />
          <div style={{ flex: 1 }}>
            <div className="a4title">تقرير متابعة المزرعة</div>
            <div className="a4sub">مزارع أبوشريف</div>
          </div>
          <div style={{ width: 70 }} />
        </div>

        <div style={{ textAlign: "center" }}><span className="a4badge">موقع التقرير: {site.name}</span></div>

        <div className="a4meta">
          <div><div className="mlabel">رقم التقرير</div><div className="mval">{reportNo}</div></div>
          <div><div className="mlabel">اسم المستخدم</div><div className="mval">👤 {currentUser?.username || "-"}</div></div>
          <div><div className="mlabel">تاريخ ووقت الطباعة</div><div className="mval">{now.toLocaleDateString("en-GB")} {now.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}</div></div>
        </div>

        <div className="a4sechead">ملخص الموقع</div>
        <div className="a4stats">
          <div className="a4box"><div className="v">{totalBirds.toLocaleString()}</div><div className="l">إجمالي الطيور الحالية</div></div>
          <div className="a4box"><div className="v">{totalMortAll.toLocaleString()}</div><div className="l">إجمالي النافق</div></div>
          <div className="a4box"><div className="v">{mortRateAll}%</div><div className="l">نسبة النفوق</div></div>
          <div className="a4box"><div className="v">{totalFeedConsumed.toFixed(0)} كجم</div><div className="l">إجمالي العلف المستهلك</div></div>
          <div className="a4box"><div className="v">{gasBalance.toFixed(0)} لتر</div><div className="l">رصيد خزان الجاز</div></div>
          <div className="a4box"><div className="v">{totalInjections}</div><div className="l">عدد عمليات الحقن والتقطير</div></div>
        </div>

        <div className="a4sechead">تفاصيل العنابر</div>
        <table className="a4tbl">
          <thead><tr><th>العنبر</th><th>تاريخ البداية</th><th>العمر</th><th>طيور البداية</th><th>الطيور الحالية</th><th>النافق</th><th>نسبة النفوق</th><th>العلف المستهلك</th><th>الحالة</th></tr></thead>
          <tbody>
            {barnStats.map((b, i) => (
              <tr key={i}>
                <td><strong>{b.barn}</strong></td>
                <td>{b.hasSession ? b.startDate : "-"}</td>
                <td>{b.hasSession ? `${b.age} يوم` : "-"}</td>
                <td>{b.hasSession ? b.birdsStart.toLocaleString() : "-"}</td>
                <td><strong>{b.hasSession ? b.birds.toLocaleString() : "-"}</strong></td>
                <td>{b.hasSession ? b.mortality : "-"}</td>
                <td>{b.hasSession ? `${((b.mortality / b.birdsStart) * 100 || 0).toFixed(2)}%` : "-"}</td>
                <td>{b.hasSession ? `${b.feed.toFixed(0)} كجم` : "-"}</td>
                <td>{b.hasSession ? "نشطة ✅" : "فارغ"}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="a4sechead">إحصائيات الدورة</div>
        <div className="a4stats">
          <div className="a4box"><div className="v">{activeBarns}</div><div className="l">عدد العنابر النشطة</div></div>
          <div className="a4box"><div className="v">{totalBirdsStart.toLocaleString()}</div><div className="l">إجمالي طيور البداية</div></div>
          <div className="a4box"><div className="v">{totalBirds.toLocaleString()}</div><div className="l">إجمالي الطيور الحالية</div></div>
          <div className="a4box"><div className="v">{totalMortAll.toLocaleString()}</div><div className="l">إجمالي النافق</div></div>
          <div className="a4box"><div className="v">{mortRateAll}%</div><div className="l">نسبة النفوق الكلية</div></div>
          <div className="a4box"><div className="v">{totalFeedConsumed.toFixed(0)} كجم</div><div className="l">إجمالي العلف المستهلك</div></div>
        </div>

        <div className="siggrid">
          <div className="sigbox">
            <div className="sigline" />
            <div style={{ fontWeight: 700, fontSize: 12 }}>توقيع مدير المزرعة</div>
          </div>
          <div className="sigbox">
            <div className="stampcircle">ختم<br />المدير</div>
          </div>
        </div>

        <div className="a4footer">مزارع أبوشريف | ABO SHERIF FARMS — تم إنشاء التقرير بتاريخ {now.toLocaleDateString("en-GB")} الساعة {now.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}</div>
      </div>
    </div>
  );
}

// ========== GAS TANK (SITE-LEVEL, RECEIVED ONLY) ==========
function GasStorePage({ siteId, data, onUpdate, isAdmin, currentUser, onBack }) {
  const canEdit = !!onUpdate;
  const site = SITES.find(s => s.id === siteId);
  const gasStore = data?.sites?.[siteId]?.gasStore || { received: [] };
  const [recForm, setRecForm] = useState({ date: new Date().toISOString().split("T")[0], qty: "", notes: "" });
  const [editRec, setEditRec] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [saved, setSaved] = useState(false);
  const [showReport, setShowReport] = useState(false);

  const totalIn = (gasStore.received || []).reduce((s, r) => s + num(r.qty), 0);

  const deepUpdate = (newReceived) => {
    if (!onUpdate) return;
    const d = JSON.parse(JSON.stringify(data));
    if (!d.sites[siteId]) return;
    d.sites[siteId].gasStore = { received: newReceived };
    onUpdate(d);
  };

  const addRec = () => {
    if (!recForm.qty || !canEdit) return;
    deepUpdate([...(gasStore.received || []), { id: genId(), ...recForm }]);
    setSaved(true); setTimeout(() => setSaved(false), 2000);
    setRecForm(p => ({ ...p, qty: "", notes: "" }));
  };

  const deleteEntry = (id) => {
    setConfirm({ msg: "هتمسح السجل ده؟", fn: () => deepUpdate((gasStore.received || []).filter(r => r.id !== id)) });
  };

  const saveEdit = () => {
    if (!editRec) return;
    deepUpdate((gasStore.received || []).map(r => r.id === editRec.id ? editRec : r));
    setEditRec(null);
  };

  const rows = [...(gasStore.received || [])].sort((a, b) => a.date > b.date ? 1 : -1);

  return (
    <div>
      {confirm && <Confirm msg={confirm.msg} onOk={() => { confirm.fn(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}
      {editRec && (
        <div className="modal-bg">
          <div className="modal">
            <div className="modal-t">✏️ تعديل السجل</div>
            <div className="g2" style={{ marginBottom: 12 }}>
              <div className="fg"><label className="lbl">التاريخ</label><input className="inp" type="date" value={editRec.date} onChange={e => setEditRec(p => ({ ...p, date: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">الكمية (لتر)</label><input className="inp" type="number" value={editRec.qty} onChange={e => setEditRec(p => ({ ...p, qty: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">ملاحظات</label><input className="inp" value={editRec.notes || ""} onChange={e => setEditRec(p => ({ ...p, notes: e.target.value }))} /></div>
            </div>
            <div style={{ display: "flex", gap: 8 }}><button className="btn btn-n" style={{ flex: 1 }} onClick={() => setEditRec(null)}>إلغاء</button><button className="btn btn-p" style={{ flex: 1 }} onClick={saveEdit}>💾 حفظ</button></div>
          </div>
        </div>
      )}

      {showReport && (
        <SimpleReport
          title="تقرير خزان الجاز"
          badge={`الموقع: ${site.name}`}
          currentUser={currentUser}
          onClose={() => setShowReport(false)}
          sections={
            <>
              <div className="a4sechead">ملخص الخزان</div>
              <div className="a4stats">
                <div className="a4box"><div className="v">{totalIn.toFixed(0)} لتر</div><div className="l">إجمالي الرصيد الحالي</div></div>
              </div>
              <div className="a4sechead">سجل وارد الجاز</div>
              <table className="a4tbl">
                <thead><tr><th>التاريخ</th><th>الكمية (لتر)</th><th>ملاحظات</th></tr></thead>
                <tbody>
                  {rows.map((r, i) => (
                    <tr key={i}><td>{r.date}</td><td>+{r.qty}</td><td>{r.notes || "-"}</td></tr>
                  ))}
                </tbody>
              </table>
            </>
          }
        />
      )}

      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 2, flexWrap: "wrap" }}>
        <button className="btn btn-n btn-sm" onClick={onBack}>← رجوع</button>
        <div className="pg-title" style={{ margin: 0 }}>🔥 خزان جاز {site.name}</div>
        <button className="btn btn-n btn-sm" style={{ marginRight: "auto" }} onClick={() => setShowReport(true)}>🖨️ طباعة تقرير</button>
      </div>
      <div className="pg-sub">خزان جاز على مستوى الموقع — بالـ لتر — رصيد تراكمي (وارد فقط)</div>

      {saved && <div className="alert alert-ok">✅ تم</div>}

      <div className="stats">
        <div className="stat"><div className="sv cg">{totalIn.toFixed(0)} لتر</div><div className="sl">إجمالي الرصيد الحالي</div></div>
      </div>

      {canEdit && (
        <div className="card">
          <div className="card-t">📥 إضافة وارد جاز</div>
          <div className="g3">
            <div className="fg"><label className="lbl">التاريخ</label><input className="inp" type="date" value={recForm.date} onChange={e => setRecForm(p => ({ ...p, date: e.target.value }))} /></div>
            <div className="fg"><label className="lbl">الكمية (لتر)</label><input className="inp" type="number" value={recForm.qty} onChange={e => setRecForm(p => ({ ...p, qty: e.target.value }))} /></div>
            <div className="fg"><label className="lbl">ملاحظات</label><input className="inp" value={recForm.notes} onChange={e => setRecForm(p => ({ ...p, notes: e.target.value }))} /></div>
          </div>
          <button className="btn btn-s btn-sm" style={{ marginTop: 10 }} onClick={addRec}>+ إضافة</button>
        </div>
      )}

      {rows.length > 0 && (
        <div className="card">
          <div className="card-t">📋 سجل وارد الجاز</div>
          <div style={{ overflowX: "auto" }}>
            <table className="tbl">
              <thead><tr><th>التاريخ</th><th>الكمية (لتر)</th><th>ملاحظات</th>{canEdit && <th>إجراء</th>}</tr></thead>
              <tbody>
                {rows.map(r => (
                  <tr key={r.id}>
                    <td>{r.date}</td>
                    <td style={{ color: C.green, fontWeight: 700 }}>+{r.qty}</td>
                    <td>{r.notes || "-"}</td>
                    {canEdit && <td><div style={{ display: "flex", gap: 3 }}><button className="btn btn-n btn-xs" onClick={() => setEditRec({ ...r })}>✏️</button>{isAdmin && <button className="btn btn-d btn-xs" onClick={() => deleteEntry(r.id)}>🗑️</button>}</div></td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ========== INJECTIONS / حقن وتقطير (SITE-LEVEL, PULLS FROM MED STORE) ==========
function InjectionsPage({ siteId, data, onUpdate, isAdmin, currentUser, onBack }) {
  const canEdit = !!onUpdate;
  const site = SITES.find(s => s.id === siteId);
  const injections = data?.sites?.[siteId]?.injections || [];
  const [form, setForm] = useState({ date: new Date().toISOString().split("T")[0], type: "حقن", name: "", qty: "", notes: "" });
  const [editRec, setEditRec] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [saved, setSaved] = useState(false);
  const [search, setSearch] = useState("");
  const [showReport, setShowReport] = useState(false);

  const addRec = () => {
    if (!form.name || !canEdit) return;
    const d = JSON.parse(JSON.stringify(data));
    const inj = d.sites[siteId].injections || [];
    inj.push({ id: genId(), ...form });
    d.sites[siteId].injections = inj;
    onUpdate(d);
    setSaved(true); setTimeout(() => setSaved(false), 2500);
    setForm({ date: form.date, type: form.type, name: "", qty: "", notes: "" });
  };

  const deleteRec = (id) => {
    setConfirm({ msg: "هتمسح السجل ده؟", fn: () => {
      const d = JSON.parse(JSON.stringify(data));
      d.sites[siteId].injections = (d.sites[siteId].injections || []).filter(r => r.id !== id);
      onUpdate(d);
    }});
  };

  const saveEdit = () => {
    if (!editRec || !canEdit) return;
    const d = JSON.parse(JSON.stringify(data));
    d.sites[siteId].injections = (d.sites[siteId].injections || []).map(r => r.id === editRec.id ? editRec : r);
    onUpdate(d);
    setEditRec(null);
  };

  const rows = [...injections].filter(r => !search || (r.name || "").toLowerCase().includes(search.toLowerCase())).sort((a, b) => a.date > b.date ? 1 : -1);
  const totalByName = {};
  injections.forEach(r => { totalByName[r.name] = (totalByName[r.name] || 0) + num(r.qty); });

  return (
    <div>
      {confirm && <Confirm msg={confirm.msg} onOk={() => { confirm.fn(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}
      {editRec && (
        <div className="modal-bg">
          <div className="modal">
            <div className="modal-t">✏️ تعديل سجل {editRec.type}</div>
            <div className="g2" style={{ marginBottom: 12 }}>
              <div className="fg"><label className="lbl">التاريخ</label><input className="inp" type="date" value={editRec.date} onChange={e => setEditRec(p => ({ ...p, date: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">النوع</label><select className="inp" value={editRec.type} onChange={e => setEditRec(p => ({ ...p, type: e.target.value }))}><option value="حقن">حقن</option><option value="تقطير">تقطير</option></select></div>
              <div className="fg"><label className="lbl">اسم الدواء</label><input className="inp" value={editRec.name} onChange={e => setEditRec(p => ({ ...p, name: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">الكمية</label><input className="inp" type="number" value={editRec.qty} onChange={e => setEditRec(p => ({ ...p, qty: e.target.value }))} /></div>
              <div className="fg"><label className="lbl">ملاحظات</label><input className="inp" value={editRec.notes || ""} onChange={e => setEditRec(p => ({ ...p, notes: e.target.value }))} /></div>
            </div>
            <div style={{ display: "flex", gap: 8 }}><button className="btn btn-n" style={{ flex: 1 }} onClick={() => setEditRec(null)}>إلغاء</button><button className="btn btn-p" style={{ flex: 1 }} onClick={saveEdit}>💾 حفظ</button></div>
          </div>
        </div>
      )}

      {showReport && (
        <SimpleReport
          title="تقرير حقن وتقطير"
          badge={`الموقع: ${site.name}`}
          currentUser={currentUser}
          onClose={() => setShowReport(false)}
          sections={
            <>
              <div className="a4sechead">إجمالي الاستخدام لكل دواء</div>
              <table className="a4tbl">
                <thead><tr><th>الدواء</th><th>إجمالي الكمية المستخدمة</th></tr></thead>
                <tbody>{Object.entries(totalByName).map(([name, qty], i) => (<tr key={i}><td><strong>{name}</strong></td><td>{qty}</td></tr>))}</tbody>
              </table>
              <div className="a4sechead">سجل الحقن والتقطير</div>
              <table className="a4tbl">
                <thead><tr><th>التاريخ</th><th>النوع</th><th>الدواء</th><th>الكمية</th><th>ملاحظات</th></tr></thead>
                <tbody>{rows.map((r, i) => (<tr key={i}><td>{r.date}</td><td>{r.type}</td><td>{r.name}</td><td>{r.qty || "-"}</td><td>{r.notes || "-"}</td></tr>))}</tbody>
              </table>
            </>
          }
        />
      )}

      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 2, flexWrap: "wrap" }}>
        <button className="btn btn-n btn-sm" onClick={onBack}>← رجوع</button>
        <div className="pg-title" style={{ margin: 0 }}>💉 حقن وتقطير {site.name}</div>
        {rows.length > 0 && <button className="btn btn-n btn-sm" style={{ marginRight: "auto" }} onClick={() => setShowReport(true)}>🖨️ طباعة تقرير</button>}
      </div>
      <div className="pg-sub">سجل مستقل — غير مرتبط بمخزن الدواء</div>

      {saved && <div className="alert alert-ok">✅ تم الحفظ</div>}

      {canEdit && (
        <div className="card">
          <div className="card-t">➕ تسجيل جديد</div>
          <div className="g3" style={{ marginBottom: 10 }}>
            <div className="fg"><label className="lbl">التاريخ</label><input className="inp" type="date" value={form.date} onChange={e => setForm(p => ({ ...p, date: e.target.value }))} /></div>
            <div className="fg"><label className="lbl">النوع</label><select className="inp" value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value }))}><option value="حقن">حقن</option><option value="تقطير">تقطير</option></select></div>
            <div className="fg"><label className="lbl">اسم الدواء</label><input className="inp" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="اكتب اسم الدواء" /></div>
          </div>
          <div className="g2">
            <div className="fg"><label className="lbl">الكمية (اختياري)</label><input className="inp" type="number" value={form.qty} onChange={e => setForm(p => ({ ...p, qty: e.target.value }))} /></div>
            <div className="fg"><label className="lbl">ملاحظات</label><input className="inp" value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} /></div>
          </div>
          <button className="btn btn-s btn-sm" style={{ marginTop: 10 }} onClick={addRec}>+ تسجيل</button>
        </div>
      )}

      {rows.length > 0 && (
        <div className="card">
          <div className="card-t">📋 سجل الحقن والتقطير</div>
          <div className="fg" style={{ maxWidth: 280, marginBottom: 12 }}>
            <label className="lbl">🔍 بحث عن دواء</label>
            <input className="inp" placeholder="اكتب اسم الدواء..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <div style={{ overflowX: "auto" }}>
            <table className="tbl">
              <thead><tr><th>التاريخ</th><th>النوع</th><th>الدواء</th><th>الكمية</th><th>ملاحظات</th>{canEdit && <th>إجراء</th>}</tr></thead>
              <tbody>
                {rows.map(r => (
                  <tr key={r.id}>
                    <td>{r.date}</td>
                    <td><span className="badge" style={{ background: r.type === "حقن" ? "rgba(192,57,43,.12)" : "rgba(41,128,185,.12)", color: r.type === "حقن" ? C.red : C.blue }}>{r.type}</span></td>
                    <td style={{ fontWeight: 700 }}>💊 {r.name}</td>
                    <td>{r.qty || "-"}</td>
                    <td>{r.notes || "-"}</td>
                    {canEdit && <td><div style={{ display: "flex", gap: 3 }}><button className="btn btn-n btn-xs" onClick={() => setEditRec({ ...r })}>✏️</button>{isAdmin && <button className="btn btn-d btn-xs" onClick={() => deleteRec(r.id)}>🗑️</button>}</div></td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ========== SITE PAGE ==========
function SitePage({ siteId, data, onSelectBarn, onDeleteSite, onBack, onOpenStore, onOpenMedStore, onOpenGasStore, onOpenInjections, onOpenArchive, currentUser }) {
  const site = SITES.find(s => s.id === siteId);
  const siteData = data?.sites?.[siteId] || { sessions: {} };
  const [confirm, setConfirm] = useState(null);
  const [showReport, setShowReport] = useState(false);

  return (
    <div>
      {confirm && <Confirm msg={confirm.msg} onOk={() => { confirm.fn(); setConfirm(null); }} onCancel={() => setConfirm(null)} />}
      {showReport && <SiteReport siteId={siteId} data={data} currentUser={currentUser} onClose={() => setShowReport(false)} />}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6, flexWrap: "wrap", gap: 8 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <button className="btn btn-n btn-sm" onClick={onBack}>← رجوع</button>
          <div className="pg-title" style={{ margin: 0 }}>🏭 {site.name}</div>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          <button className="btn btn-n btn-sm" onClick={() => setShowReport(true)}>🖨️ تقرير الموقع</button>
          {onDeleteSite && <button className="btn btn-d btn-sm" onClick={() => setConfirm({ msg: `هتمسح كل دورات "${site.name}" ومخزن العلف ومخزن الدواء وخزان الجاز وسجل الحقن والتقطير نهائي!`, fn: () => onDeleteSite(siteId) })}>🗑️ حذف الكل</button>}
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
        <button onClick={() => onOpenStore(siteId)} style={{ flex: "1 1 140px", background: C.card, border: `1.5px solid ${C.accent}`, borderRadius: 10, padding: "10px 14px", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: C.accent }}>🌾 مخزن العلف</button>
        <button onClick={() => onOpenMedStore(siteId)} style={{ flex: "1 1 140px", background: C.card, border: `1.5px solid ${C.purple}`, borderRadius: 10, padding: "10px 14px", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: C.purple }}>💊 مخزن الدواء</button>
        <button onClick={() => onOpenGasStore(siteId)} style={{ flex: "1 1 140px", background: C.card, border: "1.5px solid #e67e22", borderRadius: 10, padding: "10px 14px", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: "#e67e22" }}>🔥 خزان الجاز</button>
        <button onClick={() => onOpenInjections(siteId)} style={{ flex: "1 1 140px", background: C.card, border: "1.5px solid #c0392b", borderRadius: 10, padding: "10px 14px", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: "#c0392b" }}>💉 حقن وتقطير</button>
        <button onClick={() => onOpenArchive(siteId)} style={{ flex: "1 1 140px", background: C.card, border: `1.5px solid ${C.muted}`, borderRadius: 10, padding: "10px 14px", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontFamily: "Cairo", fontWeight: 700, fontSize: 12, color: C.text }}>📦 الأرشيف</button>
      </div>

      <div className="pg-sub">اختر العنبر</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 14 }}>
        {site.barns.map(barn => {
          const session = siteData?.sessions?.[barn];
          const hasSession = !!session;
          const totalMort = hasSession ? (session.dailyRecords || []).reduce((s, r) => s + calcDayStats(r).mortality, 0) : 0;
          const age = hasSession ? calcAge(session.startDate) : 0;
          const remaining = hasSession ? num(session.birdCount) - totalMort : 0;
          return (
            <div key={barn} onClick={() => onSelectBarn(siteId, barn)}
              style={{ background: C.card, border: `2px solid ${hasSession ? C.green : C.border}`, borderRadius: 14, padding: 16, cursor: "pointer", transition: "all .2s", boxShadow: "0 1px 5px rgba(0,0,0,.05)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                <div style={{ fontSize: 15, fontWeight: 800 }}>🐔 {barn}</div>
                <span style={{ fontSize: 10, fontWeight: 700, padding: "2px 8px", borderRadius: 16, background: hasSession ? "rgba(30,140,78,.12)" : C.cardAlt, color: hasSession ? C.green : C.muted }}>{hasSession ? "نشطة ✅" : "فارغ"}</span>
              </div>
              {hasSession ? (
                <div style={{ fontSize: 11, color: C.muted }}>
                  <div>📅 بداية: <strong style={{ color: C.text }}>{session.startDate}</strong></div>
                  <div>📆 العمر: <strong style={{ color: C.accent }}>{age} يوم</strong></div>
                  <div>🐔 الطيور: <strong style={{ color: C.text }}>{remaining.toLocaleString()}</strong></div>
                </div>
              ) : <div style={{ fontSize: 11, color: C.muted }}>لا توجد دورة نشطة</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ========== HOME PAGE ==========
function HomePage({ data, onSelectSite, onSelectBarn, allowedSites }) {
  return (
    <div>
      <div className="pg-title">🏠 لوحة التحكم</div>
      <div className="pg-sub">اختر موقعاً للبدء</div>
      <div className="home-grid">
        {allowedSites.map(site => {
          const sd = data?.sites?.[site.id];
          const active = site.barns.filter(b => sd?.sessions?.[b]).length;
          return (
            <div className="site-card" key={site.id} onClick={() => onSelectSite(site.id)}>
              <div style={{ fontWeight: 800, fontSize: 14, marginBottom: 5 }}>🏭 {site.name}</div>
              <div style={{ fontSize: 11, color: C.muted }}>{site.barns.length} عنابر | {active} دورات نشطة</div>
              <div className="barn-tags">
                {site.barns.map(b => (
                  <span key={b} className={`btag ${sd?.sessions?.[b] ? "on" : ""}`} onClick={e => { e.stopPropagation(); onSelectBarn(site.id, b); }}>{b}</span>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ========== MAIN APP ==========
export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [data, setData] = useState(makeEmpty);
  const [loading, setLoading] = useState(true);
  const [selectedSite, setSelectedSite] = useState(null);
  const [selectedBarn, setSelectedBarn] = useState(null);
  const [showArchive, setShowArchive] = useState(false);
  const [showStore, setShowStore] = useState(false);
  const [showMedStore, setShowMedStore] = useState(false);
  const [showGasStore, setShowGasStore] = useState(false);
  const [showInjections, setShowInjections] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [expanded, setExpanded] = useState({});
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [syncStatus, setSyncStatus] = useState("");

  useEffect(() => {
    loadSaved().then(d => { if (d) setData(d); setLoading(false); }).catch(() => setLoading(false));
    try {
      const saved = sessionStorage.getItem("current_user");
      if (saved) {
        const u = JSON.parse(saved);
        setCurrentUser(u);
        fetch(`${SUPA_URL}/rest/v1/users?id=eq.${u.id}&select=*`, { headers: SUPA_HDR })
          .then(r => r.json()).then(rows => { if (rows?.[0]) { setCurrentUser(rows[0]); try { sessionStorage.setItem("current_user", JSON.stringify(rows[0])); } catch {} } }).catch(() => {});
      }
    } catch {}
  }, []);

  useEffect(() => {
    if (!currentUser || loading) return;
    setSyncStatus("saving");
    saveData(data).then(() => { setSyncStatus("saved"); setTimeout(() => setSyncStatus(""), 3000); }).catch(() => setSyncStatus("error"));
  }, [data]);

  const handleLogin = async (user) => {
    try {
      const res = await fetch(`${SUPA_URL}/rest/v1/users?id=eq.${user.id}&select=*`, { headers: SUPA_HDR });
      const rows = await res.json();
      const u = rows?.[0] || user;
      setCurrentUser(u);
      try { sessionStorage.setItem("current_user", JSON.stringify(u)); } catch {}
    } catch { setCurrentUser(user); try { sessionStorage.setItem("current_user", JSON.stringify(user)); } catch {} }
  };

  const handleLogout = () => { setCurrentUser(null); try { sessionStorage.removeItem("current_user"); } catch {} };
  const updateData = (d) => setData(mergeData(d));

  const allowedSites = currentUser?.role === "admin" || !(currentUser?.allowed_sites?.length) ? SITES : SITES.filter(s => currentUser.allowed_sites.includes(s.id));
  const canEdit = currentUser?.role === "admin" || currentUser?.can_edit;
  const isAdmin = currentUser?.role === "admin";

  const goHome = () => { setSelectedSite(null); setSelectedBarn(null); setShowArchive(false); setShowStore(false); setShowMedStore(false); setShowGasStore(false); setShowInjections(false); setShowSettings(false); setSidebarOpen(false); };
  const selectSite = (id) => { setSelectedSite(id); setSelectedBarn(null); setShowArchive(false); setShowStore(false); setShowMedStore(false); setShowGasStore(false); setShowInjections(false); setShowSettings(false); setExpanded(e => ({ ...e, [id]: true })); setSidebarOpen(false); };
  const selectBarn = (siteId, barn) => { setSelectedSite(siteId); setSelectedBarn(barn); setShowArchive(false); setShowStore(false); setShowMedStore(false); setShowGasStore(false); setShowInjections(false); setShowSettings(false); setExpanded(e => ({ ...e, [siteId]: true })); setSidebarOpen(false); };
  const openStore = (siteId) => { setSelectedSite(siteId); setSelectedBarn(null); setShowArchive(false); setShowStore(true); setShowMedStore(false); setShowGasStore(false); setShowInjections(false); setShowSettings(false); };
  const openMedStore = (siteId) => { setSelectedSite(siteId); setSelectedBarn(null); setShowArchive(false); setShowStore(false); setShowMedStore(true); setShowGasStore(false); setShowInjections(false); setShowSettings(false); };
  const openGasStore = (siteId) => { setSelectedSite(siteId); setSelectedBarn(null); setShowArchive(false); setShowStore(false); setShowMedStore(false); setShowGasStore(true); setShowInjections(false); setShowSettings(false); };
  const openInjections = (siteId) => { setSelectedSite(siteId); setSelectedBarn(null); setShowArchive(false); setShowStore(false); setShowMedStore(false); setShowGasStore(false); setShowInjections(true); setShowSettings(false); };
  const openArchive = (siteId) => { setSelectedSite(siteId); setSelectedBarn(null); setShowArchive(true); setShowStore(false); setShowMedStore(false); setShowGasStore(false); setShowInjections(false); setShowSettings(false); };

  const deleteSite = (siteId) => {
    const d = JSON.parse(JSON.stringify(data));
    SITES.find(s => s.id === siteId)?.barns.forEach(b => { if (d.sites[siteId]) d.sites[siteId].sessions[b] = null; });
    if (d.sites[siteId]) {
      d.sites[siteId].feedStore = { received: [], dispatched: [] };
      d.sites[siteId].medStore = { received: [] };
      d.sites[siteId].gasStore = { received: [] };
      d.sites[siteId].injections = [];
    }
    setData(d);
  };

  const renderContent = () => {
    try {
      if (showSettings) return <SettingsPage currentUser={currentUser} data={data} onUpdate={updateData} onDataRestore={d => setData(mergeData(d))} />;
      if (showArchive && selectedSite) return <ArchivePage data={data} onUpdate={updateData} siteId={selectedSite} onBack={() => { setShowArchive(false); }} />;
      if (showStore && selectedSite) return <SiteStorePage siteId={selectedSite} data={data} onUpdate={canEdit ? updateData : null} isAdmin={isAdmin} currentUser={currentUser} onBack={() => setShowStore(false)} />;
      if (showMedStore && selectedSite) return <MedStorePage siteId={selectedSite} data={data} onUpdate={canEdit ? updateData : null} isAdmin={isAdmin} currentUser={currentUser} onBack={() => setShowMedStore(false)} />;
      if (showGasStore && selectedSite) return <GasStorePage siteId={selectedSite} data={data} onUpdate={canEdit ? updateData : null} isAdmin={isAdmin} currentUser={currentUser} onBack={() => setShowGasStore(false)} />;
      if (showInjections && selectedSite) return <InjectionsPage siteId={selectedSite} data={data} onUpdate={canEdit ? updateData : null} isAdmin={isAdmin} currentUser={currentUser} onBack={() => setShowInjections(false)} />;
      if (selectedSite && selectedBarn) return <BarnPage siteId={selectedSite} barnName={selectedBarn} data={data} onUpdate={updateData} canEdit={canEdit} isAdmin={isAdmin} currentUser={currentUser} onBack={() => setSelectedBarn(null)} />;
      if (selectedSite && !selectedBarn) return <SitePage siteId={selectedSite} data={data} onSelectBarn={selectBarn} onDeleteSite={isAdmin ? deleteSite : null} onBack={goHome} onOpenStore={openStore} onOpenMedStore={openMedStore} onOpenGasStore={openGasStore} onOpenInjections={openInjections} onOpenArchive={openArchive} currentUser={currentUser} />;
      return <HomePage data={data} onSelectSite={selectSite} onSelectBarn={selectBarn} allowedSites={allowedSites} />;
    } catch (e) {
      return <div className="empty"><div className="ico">⚠️</div><p>حدث خطأ</p><button className="btn btn-p" style={{ marginTop: 12 }} onClick={goHome}>🏠 الرئيسية</button></div>;
    }
  };

  if (loading) return (
    <div style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 14 }}>
      <style>{css}</style>
      <img src="/logo.png" alt="logo" style={{ width: 150, height: 150, objectFit: "contain" }} onError={e => { e.target.style.display='none'; }} />
      <div style={{ fontSize: 23, fontWeight: 800, color: C.accent, letterSpacing: 2 }}>مزارع أبوشريف</div>
      <div style={{ fontSize: 12, color: C.muted }}>جاري التحميل...</div>
    </div>
  );

  if (!currentUser) return <Login onLogin={handleLogin} />;

  return (
    <div className="app">
      <style>{css}</style>
      {sidebarOpen && <div onClick={() => setSidebarOpen(false)} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 200 }} />}

      <div className="topbar">
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button className="menu-btn" onClick={() => setSidebarOpen(o => !o)}>☰</button>
          <div className="logo">
            <img src="/logo.png" alt="logo" style={{ width: 42, height: 42, objectFit: "contain", borderRadius: 6 }} onError={e => { e.target.style.display='none'; }} />
            <div><div>مزارع أبوشريف</div><div className="logo-sub">MAZARIE ABO SHERIF</div></div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
          {syncStatus === "saving" && <span style={{ fontSize: 11, color: C.accent }}>⏳</span>}
          {syncStatus === "saved" && <span style={{ fontSize: 11, color: C.green }}>✅</span>}
          {syncStatus === "error" && <span style={{ fontSize: 11, color: C.red }}>❌</span>}
          <button className="btn btn-n btn-sm" onClick={goHome}>🏠</button>
        </div>
      </div>

      <div className="main">
        <div className={`sidebar ${sidebarOpen ? "open" : ""}`}>
          <div className="sec-lbl">المواقع والعنابر</div>
          {allowedSites.map(site => (
            <div key={site.id}>
              <button className={`site-btn ${selectedSite === site.id && !selectedBarn && !showStore ? "active" : ""}`} onClick={() => { setExpanded(e => ({ ...e, [site.id]: !e[site.id] })); selectSite(site.id); }}>
                <span>🏭</span><span style={{ flex: 1 }}>{site.name}</span><span style={{ fontSize: 10 }}>{expanded[site.id] ? "▲" : "▼"}</span>
              </button>
              {expanded[site.id] && (
                <>
                  {site.barns.map(barn => (
                    <button key={barn} className={`barn-btn ${selectedSite === site.id && selectedBarn === barn ? "active" : ""}`} onClick={() => selectBarn(site.id, barn)}>
                      <span className={`dot ${data?.sites?.[site.id]?.sessions?.[barn] ? "on" : ""}`} />{barn}
                    </button>
                  ))}
                </>
              )}
            </div>
          ))}
          <div style={{ borderTop: `1px solid ${C.border}`, marginTop: 10, paddingTop: 6 }}>
            <div className="sec-lbl">👤 {currentUser?.username} — {currentUser?.role === "admin" ? "مدير" : currentUser?.can_edit ? "محرر" : "مشاهد"}</div>
            <button className={`barn-btn ${showSettings ? "active" : ""}`} onClick={() => { setShowSettings(true); setShowArchive(false); setSelectedBarn(null); setShowStore(false); setSidebarOpen(false); }}>
              <span className="dot" style={{ background: C.purple }} />⚙️ الإعدادات
            </button>
            <button className="barn-btn" onClick={handleLogout}>
              <span className="dot" style={{ background: C.red }} />🔒 تسجيل الخروج
            </button>
          </div>
        </div>
        <div className="content">{renderContent()}</div>
      </div>
    </div>
  );
}
